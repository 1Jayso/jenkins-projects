CREATE TABLE public.si_admission_record
(
    record_id character varying(64) COLLATE pg_catalog."default" NOT NULL,
    created timestamp without time zone,
    created_by character varying(64) COLLATE pg_catalog."default",
    gk_id character varying(64) COLLATE pg_catalog."default",
    record_status character varying(16) COLLATE pg_catalog."default",
    replaces character varying(64) COLLATE pg_catalog."default",
    version_ integer,
    ext character varying(64) COLLATE pg_catalog."default",
    adm_reviewtask_list text COLLATE pg_catalog."default",
    adm_date timestamp without time zone,
    adm_flow_status character varying(64) COLLATE pg_catalog."default",
    adm_just_doc_record_id character varying(64) COLLATE pg_catalog."default",
    adm_last_residence_id character varying(64) COLLATE pg_catalog."default",
    adm_officerid character varying(64) COLLATE pg_catalog."default",
    adm_pay_record_id character varying(64) COLLATE pg_catalog."default",
    adm_prev_adm_record_id character varying(64) COLLATE pg_catalog."default",
    adm_prev_pay_record_id character varying(64) COLLATE pg_catalog."default",
    adm_reason character varying(64) COLLATE pg_catalog."default",
    adm_rev_date timestamp without time zone,
    adm_rev_penalty integer,
    adm_rev_pending integer,
    adm_rev_result character varying(64) COLLATE pg_catalog."default",
    adm_rev_resultmessage character varying(512) COLLATE pg_catalog."default",
    adm_rev_status character varying(64) COLLATE pg_catalog."default",
    adm_stationid character varying(64) COLLATE pg_catalog."default",
    adm_statusmessage character varying(512) COLLATE pg_catalog."default",
    other_properties text COLLATE pg_catalog."default",
    history_column text COLLATE pg_catalog."default",
    CONSTRAINT si_admission_record_pkey PRIMARY KEY (record_id)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.si_admission_record
    OWNER to gkspire;
-- Index: uk_3r75bdf2nl4n1pmbc8yc2i0h5

-- DROP INDEX public.uk_3r75bdf2nl4n1pmbc8yc2i0h5;

CREATE INDEX uk_3r75bdf2nl4n1pmbc8yc2i0h5
    ON public.si_admission_record USING btree
    (adm_flow_status COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: uk_gc7v3r089i0b0qycd3969ke26

-- DROP INDEX public.uk_gc7v3r089i0b0qycd3969ke26;

CREATE INDEX uk_gc7v3r089i0b0qycd3969ke26
    ON public.si_admission_record USING btree
    (adm_rev_pending ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: uk_ium5vssx2e0utbyfrcqo35kh8

-- DROP INDEX public.uk_ium5vssx2e0utbyfrcqo35kh8;

CREATE INDEX uk_ium5vssx2e0utbyfrcqo35kh8
    ON public.si_admission_record USING btree
    (gk_id COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;



-- Table: public.det_admission_records

-- DROP TABLE public.det_admission_records;

CREATE TABLE public.det_admission_records
(
    record_id character varying(64) COLLATE pg_catalog."default" NOT NULL,
    created timestamp without time zone,
    created_by character varying(64) COLLATE pg_catalog."default",
    gk_id character varying(64) COLLATE pg_catalog."default",
    record_status character varying(16) COLLATE pg_catalog."default",
    replaces character varying(64) COLLATE pg_catalog."default",
    version_ integer,
    md_5hash character varying(255) COLLATE pg_catalog."default",
    ext character varying(64) COLLATE pg_catalog."default",
    admission_records text COLLATE pg_catalog."default",
    CONSTRAINT det_admission_records_pkey PRIMARY KEY (record_id)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.det_admission_records
    OWNER to gkspire;