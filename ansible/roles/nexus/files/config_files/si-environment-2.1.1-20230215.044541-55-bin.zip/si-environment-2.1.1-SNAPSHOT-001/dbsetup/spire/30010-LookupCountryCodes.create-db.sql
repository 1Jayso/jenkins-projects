create table lookup_profession (
    KEY_ varchar(4),
    TAG varchar(64) not null,
    EXT_MAPPING varchar(16),
    COMMENT_ varchar(128),
    ISDEFAULT boolean,
    prefOrder integer,
    --
    EN varchar(128) not null,
    FR varchar(128),
    DE varchar(128),
    SW varchar(128),
    ES varchar(128),
    PT varchar(128),
    --
    primary key (KEY_)
);

create table lookup_countrycode (
    KEY_ varchar(4),
    TAG varchar(64) not null,
    EXT_MAPPING varchar(16),
    COMMENT_ varchar(128),
    ISDEFAULT boolean,
    prefOrder integer,
    --
    EN varchar(128) not null,
    FR varchar(128),
    DE varchar(128),
    SW varchar(128),
    ES varchar(128),
    PT varchar(128),
    --
    primary key (KEY_)
);


insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('AF','Afghanistan','AF','',false,0,'Afghanistan','L''Afghanistan','Afghanistan','Afghanistan','Afganistán','Afeganistão');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('AX','Åland Islands','AX','',false,0,'Åland Islands','Iles Aland','Ålandinseln','Visiwa vya Åland','Islas Aland','Ilhas Aland');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('AL','Albania','AL','',false,0,'Albania','Albanie','Albanien','Albania','Albania','Albânia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('DZ','Algeria','DZ','',false,0,'Algeria','Algérie','Algerien','Algeria','Argelia','Argélia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('AS','American Samoa','AS','',false,0,'American Samoa','Samoa américaines','Amerikanischen Samoa-Inseln','Samoa ya Marekani','Samoa Americana','Samoa Americana');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('AD','AndorrA','AD','',false,0,'AndorrA','AndorrA','Andorra','AndorrA','AndorrA','AndorrA');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('AO','Angola','AO','',false,0,'Angola','L''Angola','Angola','Angola','Angola','Angola');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('AI','Anguilla','AI','',false,0,'Anguilla','Anguilla','Anguilla','Anguilla','Anguila','Anguilla');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('AQ','Antarctica','AQ','',false,0,'Antarctica','Antarctique','Antarktis','Antaktika','Antártida','Antártica');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('AG','Antigua and Barbuda','AG','',false,0,'Antigua and Barbuda','Antigua-et-Barbuda','Antigua und Barbuda','Antigua na Barbuda','Antigua y Barbuda','Antigua e Barbuda');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('AR','Argentina','AR','',false,0,'Argentina','Argentine','Argentinien','Ajentina','Argentina','Argentina');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('AM','Armenia','AM','',false,0,'Armenia','Arménie','Armenien','Armenia','Armenia','Armênia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('AW','Aruba','AW','',false,0,'Aruba','Aruba','Aruba','Aruba','Aruba','Aruba');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('AU','Australia','AU','',false,0,'Australia','Australie','Australien','Australia','Australia','Austrália');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('AT','Austria','AT','',false,0,'Austria','L''Autriche','Österreich','Austria','Austria','Áustria');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('AZ','Azerbaijan','AZ','',false,0,'Azerbaijan','Azerbaïdjan','Aserbaidschan','Azabajani','Azerbaiyán','Azerbaijão');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('BS','Bahamas','BS','',false,0,'Bahamas','Bahamas','Bahamas','Bahamas','Bahamas','Bahamas');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('BH','Bahrain','BH','',false,0,'Bahrain','Bahreïn','Bahrain','Bahrain','Bahréin','Bahrain');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('BD','Bangladesh','BD','',false,0,'Bangladesh','Bangladesh','Bangladesch','Bangladesh','Bangladesh','Bangladesh');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('BB','Barbados','BB','',false,0,'Barbados','Barbade','Barbados','Barbados','Barbados','Barbados');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('BY','Belarus','BY','',false,0,'Belarus','Biélorussie','Weißrussland','Belarusi','Bielorrusia','Bielo-Rússia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('BE','Belgium','BE','',false,0,'Belgium','Belgique','Belgien','Ubelgiji','Bélgica','Bélgica');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('BZ','Belize','BZ','',false,0,'Belize','Belize','Belize','Belize','Belice','Belize');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('BJ','Benin','BJ','',false,0,'Benin','Bénin','Benin','Benin','Benin','Benin');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('BM','Bermuda','BM','',false,0,'Bermuda','Bermudes','Bermuda','Bermuda','islas Bermudas','Bermudas');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('BT','Bhutan','BT','',false,0,'Bhutan','Bhoutan','Bhutan','Bhutan','Bután','Butão');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('BO','Bolivia','BO','',false,0,'Bolivia','Bolivie','Bolivien','Bolivia','Bolivia','Bolívia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('BA','Bosnia and Herzegovina','BA','',false,0,'Bosnia and Herzegovina','Bosnie Herzégovine','Bosnien und Herzegowina','Bosnia na Herzegovina','Bosnia y Herzegovina','Bósnia e Herzegovina');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('BW','Botswana','BW','',false,0,'Botswana','Botswana','Botswana','Botswana','Botswana','Botswana');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('BV','Bouvet Island','BV','',false,0,'Bouvet Island','Île Bouvet','Bouvet Island','Kisiwa cha Bouvet','Isla Bouvet','Ilha Bouvet');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('BR','Brazil','BR','',false,0,'Brazil','Brésil','Brasilien','Brazil','Brasil','Brasil');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('IO','British Indian Ocean Territory','IO','',false,0,'British Indian Ocean Territory','Territoire britannique de l''océan Indien','Britisches Territorium des Indischen Ozeans','Wilaya ya Bahari ya Hindi ya Uingereza','Territorio Británico del Océano Índico','Território Britânico do Oceano Índico');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('BN','Brunei Darussalam','BN','',false,0,'Brunei Darussalam','Brunei Darussalam','Brunei Darussalam','Brunei Darussalam','Brunei Darussalam','Brunei Darussalam');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('BG','Bulgaria','BG','',false,0,'Bulgaria','Bulgarie','Bulgarien','Bulgaria','Bulgaria','Bulgária');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('BF','Burkina Faso','BF','',false,0,'Burkina Faso','Burkina Faso','Burkina Faso','Burkina Faso','Burkina Faso','Burkina Faso');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('BI','Burundi','BI','',false,0,'Burundi','Burundi','Burundi','Burundi','Burundi','Burundi');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('KH','Cambodia','KH','',false,0,'Cambodia','Cambodge','Kambodscha','Kambodia','Camboya','Camboja');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('CM','Cameroon','CM','',false,0,'Cameroon','Cameroun','Kamerun','Kamerun','Camerún','Camarões');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('CA','Canada','CA','',false,0,'Canada','Canada','Kanada','Canada','Canadá','Canadá');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('CV','Cape Verde','CV','',false,0,'Cape Verde','Cap-Vert','Kap Verde','Cape Verde','Cabo Verde','cabo Verde');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('KY','Cayman Islands','KY','',false,0,'Cayman Islands','Îles Caïmans','Cayman Inseln','Visiwa vya Cayman','Islas Caimán','Ilhas Cayman');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('CF','Central African Republic','CF','',false,0,'Central African Republic','République centrafricaine','Zentralafrikanische Republik','Jamhuri ya Afrika ya Kati','República Centroafricana','República Centro-Africana');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('TD','Chad','TD','',false,0,'Chad','Tchad','Tschad','Chad','Chad','Chade');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('CL','Chile','CL','',false,0,'Chile','Chili','Chile','Chile','Chile','Chile');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('CN','China','CN','',false,0,'China','Chine','China','Uchina','porcelana','China');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('CX','Christmas Island','CX','',false,0,'Christmas Island','L''île de noël','Weihnachtsinsel','Kisiwa cha Krismasi','Isla de Navidad','Ilha do Natal');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('CC','Cocos (Keeling) Islands','CC','',false,0,'Cocos (Keeling) Islands','Îles Cocos (Keeling)','Kokosinseln (Keelinginseln)','Visiwa vya Cocos (Keeling)','Islas Cocos (Keeling)','Ilhas Cocos (Keeling)');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('CO','Colombia','CO','',false,0,'Colombia','Colombie','Kolumbien','Kolombia','Colombia','Colômbia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('KM','Comoros','KM','',false,0,'Comoros','Comores','Komoren','Comoro','Comoras','Comores');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('CG','Congo','CG','',false,0,'Congo','Congo','Kongo','Kongo','Congo','Congo');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('CD','Congo, The Democratic Republic of the','CD','',false,0,'Congo, The Democratic Republic of the','Congo, République démocratique du','Kongo, Demokratische Republik','Kongo, Jamhuri ya Kidemokrasia ya','Congo, República Democrática del','Congo, República Democrática do');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('CK','Cook Islands','CK','',false,0,'Cook Islands','les Îles Cook','Cookinseln','Visiwa vya Cook','Islas Cook','Ilhas Cook');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('CR','Costa Rica','CR','',false,0,'Costa Rica','Costa Rica','Costa Rica','Costa Rica','Costa Rica','Costa Rica');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('CI','Ivory Coast','CI','',false,0,'Ivory Coast','Côte d''Ivoire','Cote D \ Ivoire','Pwani ya Pembe','Costa de Marfil','Costa do Marfim');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('HR','Croatia','HR','',false,0,'Croatia','Croatie','Kroatien','Kroatia','Croacia','Croácia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('CU','Cuba','CU','',false,0,'Cuba','Cuba','Kuba','Cuba','Cuba','Cuba');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('CY','Cyprus','CY','',false,0,'Cyprus','Chypre','Zypern','Kupro','Chipre','Chipre');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('CZ','Czech Republic','CZ','',false,0,'Czech Republic','République Tchèque','Tschechien','Jamhuri ya Czech','República Checa','República Checa');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('DK','Denmark','DK','',false,0,'Denmark','Danemark','Dänemark','Denmark','Dinamarca','Dinamarca');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('DJ','Djibouti','DJ','',false,0,'Djibouti','Djibouti','Dschibuti','Djibouti','Djibouti','Djibouti');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('DM','Dominica','DM','',false,0,'Dominica','Dominique','Dominica','Dominika','Dominica','Dominica');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('DO','Dominican Republic','DO','',false,0,'Dominican Republic','République Dominicaine','Dominikanische Republik','Jamhuri ya Dominika','República Dominicana','República Dominicana');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('EC','Ecuador','EC','',false,0,'Ecuador','Equateur','Ecuador','Ekvado','Ecuador','Equador');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('EG','Egypt','EG','',false,0,'Egypt','Egypte','Ägypten','Misri','Egipto','Egito');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('SV','El Salvador','SV','',false,0,'El Salvador','Le Salvador','El Salvador','El Salvador','El Salvador','El Salvador');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('GQ','Equatorial Guinea','GQ','',false,0,'Equatorial Guinea','Guinée Équatoriale','Äquatorialguinea','Guinea ya Ikweta','Guinea Ecuatorial','Guiné Equatorial');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('ER','Eritrea','ER','',false,0,'Eritrea','Érythrée','Eritrea','Eritrea','Eritrea','Eritreia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('EE','Estonia','EE','',false,0,'Estonia','Estonie','Estland','Estonia','Estonia','Estônia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('ET','Ethiopia','ET','',false,0,'Ethiopia','Ethiopie','Äthiopien','Ethiopia','Etiopía','Etiópia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('FK','Falkland Islands (Malvinas)','FK','',false,0,'Falkland Islands (Malvinas)','Îles Falkland (Malvinas)','Falklandinseln (Malvinas)','Visiwa vya Falkland (Malvinas)','Islas Falkland (Malvinas)','Ilhas Falkland (Malvinas)');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('FO','Faroe Islands','FO','',false,0,'Faroe Islands','Îles Féroé','Färöer Inseln','Visiwa vya Faroe','Islas Faroe','ilhas Faroe');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('FJ','Fiji','FJ','',false,0,'Fiji','Fidji','Fidschi','Fiji','Fiyi','Fiji');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('FI','Finland','FI','',false,0,'Finland','Finlande','Finnland','Ufini','Finlandia','Finlândia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('FR','France','FR','',false,0,'France','France','Frankreich','Ufaransa','Francia','França');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('GF','French Guiana','GF','',false,0,'French Guiana','Guyane Française','Französisch-Guayana','Kifaransa Guiana','Guayana Francesa','Guiana Francesa');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('PF','French Polynesia','PF','',false,0,'French Polynesia','Polynésie française','Französisch Polynesien','Polynesia ya Ufaransa','Polinesia francés','Polinésia Francesa');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('TF','French Southern Territories','TF','',false,0,'French Southern Territories','Terres australes françaises','Südfranzösische Territorien','Maeneo ya Kusini mwa Ufaransa','Territorios Franceses del Sur','Territórios Franceses do Sul');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('GA','Gabon','GA','',false,0,'Gabon','Gabon','Gabun','Gabon','Gabón','Gabão');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('GM','Gambia','GM','',false,0,'Gambia','Gambie','Gambia','Gambia','Gambia','Gâmbia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('GE','Georgia','GE','',false,0,'Georgia','Géorgie','Georgia','Georgia','Georgia','Georgia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('DE','Germany','DE','',false,0,'Germany','Allemagne','Deutschland','Ujerumani','Alemania','Alemanha');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('GH','Ghana','GH','',false,0,'Ghana','Ghana','Ghana','Ghana','Ghana','Gana');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('GI','Gibraltar','GI','',false,0,'Gibraltar','Gibraltar','Gibraltar','Gibraltar','Gibraltar','Gibraltar');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('GR','Greece','GR','',false,0,'Greece','Grèce','Griechenland','Ugiriki','Grecia','Grécia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('GL','Greenland','GL','',false,0,'Greenland','Groenland','Grönland','Greenland','Groenlandia','Groenlândia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('GD','Grenada','GD','',false,0,'Grenada','Grenade','Grenada','Grenada','Granada','Grenada');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('GP','Guadeloupe','GP','',false,0,'Guadeloupe','Guadeloupe','Guadeloupe','Guadeloupe','Guadalupe','Guadalupe');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('GU','Guam','GU','',false,0,'Guam','Guam','Guam','Guam','Guam','Guam');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('GT','Guatemala','GT','',false,0,'Guatemala','Guatemala','Guatemala','Guatemala','Guatemala','Guatemala');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('GG','Guernsey','GG','',false,0,'Guernsey','Guernesey','Guernsey','Guernsey','Guernsey','Guernsey');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('GN','Guinea','GN','',false,0,'Guinea','Guinée','Guinea','Gine','Guinea','Guiné');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('GW','Guinea-Bissau','GW','',false,0,'Guinea-Bissau','Guinée-Bissau','Guinea-Bissau','Guinea-Bissau','Guinea-Bissau','Guiné-bissau');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('GY','Guyana','GY','',false,0,'Guyana','Guyane','Guyana','Guyana','Guayana','Guiana');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('HT','Haiti','HT','',false,0,'Haiti','Haïti','Haiti','Haiti','Haití','Haiti');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('HM','Heard Island and Mcdonald Islands','HM','',false,0,'Heard Island and Mcdonald Islands','Île Heard et Îles Mcdonald','Heard Island und Mcdonald Islands','Kisiwa cha Heard na Visiwa vya Mcdonald','Isla Heard e Islas Mcdonald','Ilha Heard e Ilhas Mcdonald');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('VA','Holy See (Vatican City State)','VA','',false,0,'Holy See (Vatican City State)','Saint-Siège (État de la Cité du Vatican)','Heiliger Stuhl (Staat der Vatikanstadt)','Holy See (Jimbo la Jiji la Vatican)','Santa Sede (Estado de la Ciudad del Vaticano)','Santa Sé (Estado da Cidade do Vaticano)');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('HN','Honduras','HN','',false,0,'Honduras','Honduras','Honduras','Honduras','Honduras','Honduras');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('HK','Hong Kong','HK','',false,0,'Hong Kong','Hong Kong','Hongkong','Hong Kong','Hong Kong','Hong Kong');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('HU','Hungary','HU','',false,0,'Hungary','Hongrie','Ungarn','Hungary','Hungría','Hungria');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('IS','Iceland','IS','',false,0,'Iceland','Islande','Island','Iceland','Islandia','Islândia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('IN','India','IN','',false,0,'India','Inde','Indien','Uhindi','India','Índia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('ID','Indonesia','ID','',false,0,'Indonesia','Indonésie','Indonesien','Indonesia','Indonesia','Indonésia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('IR','Iran','IR','',false,0,'Iran','Iran ','Iran','Irani','Irán','Irã');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('IQ','Iraq','IQ','',false,0,'Iraq','Irak','Irak','Iraq','Irak','Iraque');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('IE','Ireland','IE','',false,0,'Ireland','Irlande','Irland','Ireland','Irlanda','Irlanda');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('IM','Isle of Man','IM','',false,0,'Isle of Man','île de Man','Isle of Man','Kisiwa cha Mtu','Isla del hombre','Ilha de Man');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('IL','Israel','IL','',false,0,'Israel','Israël','Israel','Israeli','Israel','Israel');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('IT','Italy','IT','',false,0,'Italy','Italie','Italien','Italia','Italia','Itália');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('JM','Jamaica','JM','',false,0,'Jamaica','Jamaïque','Jamaika','Jamaika','Jamaica','Jamaica');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('JP','Japan','JP','',false,0,'Japan','Japon','Japan','Japani','Japón','Japão');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('JE','Jersey','JE','',false,0,'Jersey','Jersey','Jersey','Jezi','Jersey','Jersey');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('JO','Jordan','JO','',false,0,'Jordan','Jordan','Jordanien','Yordani','Jordán','Jordânia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('KZ','Kazakhstan','KZ','',false,0,'Kazakhstan','Kazakhstan','Kasachstan','Kazakhstan','Kazajstán','Cazaquistão');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('KE','Kenya','KE','',false,0,'Kenya','Kenya','Kenia','Kenya','Kenia','Quênia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('KI','Kiribati','KI','',false,0,'Kiribati','Kiribati','Kiribati','Kiribati','Kiribati','Kiribati');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('KP','Korea, Democratic Peoples Republic of','KP','',false,0,'Korea, Democratic Peoples Republic of','République populaire démocratique de Corée','Korea, Demokratische Volksrepublik','Korea, Jamhuri ya Kidemokrasia ya Watu wa','República de Corea, Popular Democrática de','Coréia, República Popular Democrática da');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('KR','Korea, Republic of','KR','',false,0,'Korea, Republic of','Corée, République de','Korea, Republik von','Korea, Jamhuri ya','Corea, república de','Republica da Coréia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('KW','Kuwait','KW','',false,0,'Kuwait','Koweit','Kuwait','Kuwait','Kuwait','Kuwait');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('KG','Kyrgyzstan','KG','',false,0,'Kyrgyzstan','Kirghizistan','Kirgisistan','Kyrgyzstan','Kirguistán','Quirguistão');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('LA','Lao Peoples Democratic Republic','LA','',false,0,'Lao Peoples Democratic Republic','République démocratique populaire lao','Demokratische Republik des laotischen Volkes','Watu wa Lao Jamhuri ya Kidemokrasia','República Democrática Popular Lao','República Democrática Popular do Laos');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('LV','Latvia','LV','',false,0,'Latvia','Lettonie','Lettland','Latvia','Letonia','Letônia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('LB','Lebanon','LB','',false,0,'Lebanon','Liban','Libanon','Lebanon','Líbano','Líbano');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('LS','Lesotho','LS','',false,0,'Lesotho','Lesotho','Lesotho','Lesotho','Lesoto','Lesoto');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('LR','Liberia','LR','',false,0,'Liberia','Libéria','Liberia','Liberia','Liberia','Libéria');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('LY','Libya','LY','',false,0,'Libya','Libye','Libyen','Libya','Libya','Libya');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('LI','Liechtenstein','LI','',false,0,'Liechtenstein','Liechtenstein','Liechtenstein','Liechtenstein','Liechtenstein','Liechtenstein');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('LT','Lithuania','LT','',false,0,'Lithuania','Lituanie','Litauen','Lithuania','Lituania','Lituânia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('LU','Luxembourg','LU','',false,0,'Luxembourg','Luxembourg','Luxemburg','Luxemburg','Luxemburgo','Luxemburgo');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('MO','Macao','MO','',false,0,'Macao','Macao','Macao','Macao','Macao','Macau');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('MK','North Macedonia','MK','',false,0,'North Macedonia','Macédoine du Nord','Nordmazedonien, Ehemalige jugoslawische Republik','Makedonia Kaskazini','Macedonia del Norte','Macedônia do Norte');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('MG','Madagascar','MG','',false,0,'Madagascar','Madagascar','Madagaskar','Madagaska','Madagascar','Madagáscar');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('MW','Malawi','MW','',false,0,'Malawi','Malawi','Malawi','Malawi','Malawi','Malawi');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('MY','Malaysia','MY','',false,0,'Malaysia','Malaisie','Malaysia','Malaysia','Malasia','Malásia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('MV','Maldives','MV','',false,0,'Maldives','Maldives','Malediven','Maldives','Maldivas','Maldivas');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('ML','Mali','ML','',false,0,'Mali','Mali','Mali','Mali','Mali','Mali');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('MT','Malta','MT','',false,0,'Malta','Malte','Malta','Malta','Malta','Malta');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('MH','Marshall Islands','MH','',false,0,'Marshall Islands','Iles Marshall','Marshallinseln','Visiwa vya Marshall','Islas Marshall','Ilhas Marshall');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('MQ','Martinique','MQ','',false,0,'Martinique','Martinique','Martinique','Martinique','Martinica','Martinica');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('MR','Mauritania','MR','',false,0,'Mauritania','Mauritanie','Mauretanien','Mauritania','Mauritania','Mauritânia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('MU','Mauritius','MU','',false,0,'Mauritius','Ile Maurice','Mauritius','Morisi','Mauricio','Maurício');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('YT','Mayotte','YT','',false,0,'Mayotte','Mayotte','Mayotte','Mayotte','Mayotte','Mayotte');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('MX','Mexico','MX','',false,0,'Mexico','Mexique','Mexiko','Mexico','México','México');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('FM','Micronesia','FM','',false,0,'Micronesia','Micronésie','Mikronesien','Micronesia','Micronesia','Micronésia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('MD','Moldova','MD','',false,0,'Moldova','Moldova','Moldawien','Moldova','Moldaviae','Moldávia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('MC','Monaco','MC','',false,0,'Monaco','Monaco','Monaco','Monaco','Mónaco','Mônaco');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('MN','Mongolia','MN','',false,0,'Mongolia','Mongolie','Mongolei','Mongolia','Mongolia','Mongólia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('MS','Montserrat','MS','',false,0,'Montserrat','Montserrat','Montserrat','Montserrat','Montserrat','Montserrat');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('MA','Morocco','MA','',false,0,'Morocco','Maroc','Marokko','Moroko','Marruecos','Marrocos');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('MZ','Mozambique','MZ','',false,0,'Mozambique','Mozambique','Mosambik','Msumbiji','Mozambique','Moçambique');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('MM','Myanmar','MM','',false,0,'Myanmar','Myanmar','Myanmar','Myanmar','Myanmar','Myanmar');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('NA','Namibia','NA','',false,0,'Namibia','Namibie','Namibia','Namibia','Namibia','Namibia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('NR','Nauru','NR','',false,0,'Nauru','Nauru','Nauru','Nauru','Nauru','Nauru');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('NP','Nepal','NP','',false,0,'Nepal','Népal','Nepal','Nepal','Nepal','Nepal');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('NL','Netherlands','NL','',false,0,'Netherlands','Pays-Bas','Niederlande','Uholanzi','Países Bajos','Países Baixos');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('AN','Netherlands Antilles','AN','',false,0,'Netherlands Antilles','Antilles néerlandaises','Niederländische Antillen','Antilles za Uholanzi','Antillas Holandesas','Antilhas Holandesas');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('NC','New Caledonia','NC','',false,0,'New Caledonia','Nouvelle Calédonie','Neu-Kaledonien','Kaledonia mpya','Nueva Caledonia','Nova Caledônia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('NZ','New Zealand','NZ','',false,0,'New Zealand','Nouvelle-Zélande','Neuseeland','New Zealand','Nueva Zelanda','Nova Zelândia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('NI','Nicaragua','NI','',false,0,'Nicaragua','Nicaragua','Nicaragua','Nikaragua','Nicaragua','Nicarágua');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('NE','Niger','NE','',false,0,'Niger','Niger','Niger','Niger','Níger','Níger');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('NG','Nigeria','NG','',false,0,'Nigeria','Nigeria','Nigeria','Nigeria','Nigeria','Nigéria');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('NU','Niue','NU','',false,0,'Niue','Niue','Niue','Niue','Niue','Niue');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('NF','Norfolk Island','NF','',false,0,'Norfolk Island','l''ile de Norfolk','Norfolkinsel','Kisiwa cha Norfolk','Isla Norfolk','Ilha Norfolk');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('MP','Northern Mariana Islands','MP','',false,0,'Northern Mariana Islands','Îles Mariannes du Nord','Nördliche Marianneninseln','Visiwa vya Mariana Kaskazini','Islas Marianas del Norte','Ilhas Marianas do Norte');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('NO','Norway','NO','',false,0,'Norway','Norvège','Norwegen','Norway','Noruega','Noruega');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('OM','Oman','OM','',false,0,'Oman','Oman','Oman','Oman','Omán','Omã');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('PK','Pakistan','PK','',false,0,'Pakistan','Pakistan','Pakistan','Pakistan','Pakistán','Paquistão');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('PW','Palau','PW','',false,0,'Palau','Palau','Palau','Palau','Palau','Palau');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('PS','Palestinian Territory, Occupied','PS','',false,0,'Palestinian Territory, Occupied','Territoire palestinien, occupé','Besetzte palästinensische Gebiete','Wilaya ya Palestina, Inakaliwa','Territorio Palestino, Ocupado','Território Palestino, Ocupado');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('PA','Panama','PA','',false,0,'Panama','Panama','Panama','Panama','Panamá','Panamá');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('PG','Papua New Guinea','PG','',false,0,'Papua New Guinea','Papouasie Nouvelle Guinée','Papua Neu-Guinea','Papua Guinea Mpya','Papúa Nueva Guinea','Papua Nova Guiné');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('PY','Paraguay','PY','',false,0,'Paraguay','Paraguay','Paraguay','Paragwai','Paraguay','Paraguai');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('PE','Peru','PE','',false,0,'Peru','Pérou','Peru','Peru','Perú','Peru');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('PH','Philippines','PH','',false,0,'Philippines','Philippines','Philippinen','Ufilipino','Filipinas','Filipinas');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('PN','Pitcairn','PN','',false,0,'Pitcairn','Pitcairn','Pitcairn','Pitcairn','Pitcairn','Pitcairn');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('PL','Poland','PL','',false,0,'Poland','Pologne','Polen','Poland','Polonia','Polônia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('PT','Portugal','PT','',false,0,'Portugal','le Portugal','Portugal','Ureno','Portugal','Portugal');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('PR','Puerto Rico','PR','',false,0,'Puerto Rico','Porto Rico','Puerto Rico','Puerto Rico','Puerto Rico','Porto Rico');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('QA','Qatar','QA','',false,0,'Qatar','Qatar','Katar','Qatar','Katar','Catar');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('RE','Reunion','RE','',false,0,'Reunion','Réunion','Wiedervereinigung','Kuungana tena','Reunión','Reunião');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('RO','Romania','RO','',false,0,'Romania','Roumanie','Rumänien','Romania','Rumania','Romênia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('RU','Russian Federation','RU','',false,0,'Russian Federation','Fédération Russe','Russische Föderation','Shirikisho la Urusi','Federación Rusa','Federação Russa');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('RW','Rwanda','RW','',false,0,'Rwanda','Rwanda','Rwanda','Rwanda','Ruanda','Ruanda');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('SH','Saint Helena','SH','',false,0,'Saint Helena','Sainte-Hélène','Heilige Helena','Mtakatifu Helena','Santa elena','Santa Helena');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('KN','Saint Kitts and Nevis','KN','',false,0,'Saint Kitts and Nevis','Saint-Christophe-et-Niévès','St. Kitts und Nevis','Mtakatifu Kitts na Nevis','Saint Kitts y Nevis','São Cristóvão e Neves');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('LC','Saint Lucia','LC','',false,0,'Saint Lucia','Sainte-Lucie','St. Lucia','Mtakatifu Lucia','Santa Lucía','Santa Lúcia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('PM','Saint Pierre and Miquelon','PM','',false,0,'Saint Pierre and Miquelon','Saint-Pierre-et-Miquelon','Saint Pierre und Miquelon','Mtakatifu Pierre na Miquelon','San Pedro y Miquelón','São Pedro e Miquelão');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('VC','Saint Vincent and the Grenadines','VC','',false,0,'Saint Vincent and the Grenadines','Saint-Vincent-et-les-Grenadines','St. Vincent und die Grenadinen','Saint Vincent na Grenadines','San Vicente y las Granadinas','São Vicente e Granadinas');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('WS','Samoa','WS','',false,0,'Samoa','Samoa','Samoa','Samoa','Samoa','Samoa');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('SM','San Marino','SM','',false,0,'San Marino','Saint Marin','San Marino','San Marino','San Marino','San Marino');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('ST','Sao Tome and Principe','ST','',false,0,'Sao Tome and Principe','Sao Tomé et Principe','Sao Tome und Principe','Sao Tome na Principe','Santo Tomé y Príncipe','São Tomé e Príncipe');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('SA','Saudi Arabia','SA','',false,0,'Saudi Arabia','Arabie Saoudite','Saudi-Arabien','Saudi Arabia','Arabia Saudita','Arábia Saudita');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('SN','Senegal','SN','',false,0,'Senegal','Sénégal','Senegal','Senegal','Senegal','Senegal');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('CS','Serbia and Montenegro','CS','',false,0,'Serbia and Montenegro','Serbie et Monténégro','Serbien und Montenegro','Serbia na Montenegro','Serbia y Montenegro','Sérvia e Montenegro');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('SC','Seychelles','SC','',false,0,'Seychelles','les Seychelles','Seychellen','Shelisheli','Seychelles','Seychelles');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('SL','Sierra Leone','SL','',false,0,'Sierra Leone','Sierra Leone','Sierra Leone','Sierra Leone','Sierra Leona','Serra Leoa');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('SG','Singapore','SG','',false,0,'Singapore','Singapour','Singapur','Singapore','Singapur','Cingapura');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('SK','Slovakia','SK','',false,0,'Slovakia','Slovaquie','Slowakei','Slovakia','Eslovaquia','Eslováquia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('SI','Slovenia','SI','',false,0,'Slovenia','Slovénie','Slowenien','Slovenia','Eslovenia','Eslovênia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('SB','Solomon Islands','SB','',false,0,'Solomon Islands','Les îles Salomon','Salomon-Inseln','Visiwa vya Solomon','Islas Salomón','Ilhas Salomão');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('SO','Somalia','SO','',false,0,'Somalia','Somalie','Somalia','Somalia','Somalia','Somália');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('ZA','South Africa','ZA','',false,0,'South Africa','Afrique du Sud','Südafrika','Africa Kusini','Sudáfrica','África do Sul');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('GS','South Georgia and the South Sandwich Islands','GS','',false,0,'South Georgia and the South Sandwich Islands','Géorgie du Sud et îles Sandwich du Sud','Süd-Georgien und die südlichen Sandwich-Inseln','Georgia Kusini na Visiwa vya Sandwich Kusini','Georgia del sur y las islas Sandwich del sur','Geórgia do Sul e Ilhas Sandwich do Sul');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('ES','Spain','ES','',false,0,'Spain','Espagne','Spanien','Uhispania','España','Espanha');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('LK','Sri Lanka','LK','',false,0,'Sri Lanka','Sri Lanka','Sri Lanka','Sri Lanka','Sri Lanka','Sri Lanka');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('SD','Sudan','SD','',false,0,'Sudan','Soudan','Sudan','Sudan','Sudán','Sudão');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('SR','Suriname','SR','',false,0,'Suriname','Suriname','Suriname','Surinam','Surinam','Suriname');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('SJ','Svalbard and Jan Mayen','SJ','',false,0,'Svalbard and Jan Mayen','Svalbard et Jan Mayen','Spitzbergen und Jan Mayen','Svalbard na Jan Mayen','Svalbard y Jan Mayen','Svalbard e Jan Mayen');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('SZ','Swaziland','SZ','',false,0,'Swaziland','Swaziland','Swasiland','Uswazi','Swazilandia','Suazilândia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('SE','Sweden','SE','',false,0,'Sweden','Suède','Schweden','Uswidi','Suecia','Suécia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('CH','Switzerland','CH','',false,0,'Switzerland','la Suisse','Schweiz','Uswizi','Suiza','Suíça');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('SY','Syrian Arab Republic','SY','',false,0,'Syrian Arab Republic','République arabe syrienne','Syrische Arabische Republik','Jamhuri ya Kiarabu ya Siria','República Árabe Siria','República Árabe da Síria');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('TW','Taiwan','TW','',false,0,'Taiwan','Taiwan','Taiwan, Provinz Chinas','Taiwan','Taiwan','Taiwan');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('TJ','Tajikistan','TJ','',false,0,'Tajikistan','Tadjikistan','Tadschikistan','Tajikistan','Tayikistán','Tajiquistão');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('TZ','Tanzania','TZ','',false,0,'Tanzania','Tanzanie','Tansania','Tanzania','Tanzania','Tanzânia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('TH','Thailand','TH','',false,0,'Thailand','Thaïlande','Thailand','Thailand','Tailandia','Tailândia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('TL','Timor-Leste','TL','',false,0,'Timor-Leste','Timor-Leste','Timor-Leste','Timor-Leste','Timor-Leste','Timor-Leste');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('TG','Togo','TG','',false,0,'Togo','Aller','Gehen','Togo','Para llevar','Ir');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('TK','Tokelau','TK','',false,0,'Tokelau','Tokelau','Tokelau','Tokelau','Tokelau','Tokelau');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('TO','Tonga','TO','',false,0,'Tonga','Tonga','Tonga','Tonga','Tonga','Tonga');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('TT','Trinidad and Tobago','TT','',false,0,'Trinidad and Tobago','Trinité-et-Tobago','Trinidad und Tobago','Trinidad na Tobago','Trinidad y Tobago','Trinidad e Tobago');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('TN','Tunisia','TN','',false,0,'Tunisia','Tunisie','Tunesien','Tunisia','Túnez','Tunísia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('TR','Turkey','TR','',false,0,'Turkey','dinde','Truthahn','Uturuki','pavo','Peru');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('TM','Turkmenistan','TM','',false,0,'Turkmenistan','Turkménistan','Turkmenistan','Turkmenistan','Turkmenistán','Turcomenistão');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('TC','Turks and Caicos Islands','TC','',false,0,'Turks and Caicos Islands','îles Turques-et-Caïques','Turks- und Caicosinseln','Visiwa vya Turks na Caicos','Islas Turcas y Caicos','Ilhas Turcas e Caicos');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('TV','Tuvalu','TV','',false,0,'Tuvalu','Tuvalu','Tuvalu','Tuvalu','Tuvalu','Tuvalu');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('UG','Uganda','UG','',false,0,'Uganda','Ouganda','Uganda','Uganda','Uganda','Uganda');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('UA','Ukraine','UA','',false,0,'Ukraine','Ukraine','Ukraine','Ukraine','Ucrania','Ucrânia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('AE','United Arab Emirates','AE','',false,0,'United Arab Emirates','Emirats Arabes Unis','Vereinigte Arabische Emirate','Falme za Kiarabu','Emiratos Árabes Unidos','Emirados Árabes Unidos');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('GB','United Kingdom','GB','',false,0,'United Kingdom','Royaume-Uni','Vereinigtes Königreich','Uingereza','Reino Unido','Reino Unido');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('US','United States','US','',false,0,'United States','États Unis','Vereinigte Staaten','Marekani','Estados Unidos','Estados Unidos');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('UM','United States Minor Outlying Islands','UM','',false,0,'United States Minor Outlying Islands','Îles mineures éloignées des États-Unis','Kleinere abgelegene Inseln der Vereinigten Staaten','Visiwa vya Amerika Ndogo Ndogo','Islas menores alejadas de los Estados Unidos','Ilhas Menores Distantes dos Estados Unidos');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('UY','Uruguay','UY','',false,0,'Uruguay','Uruguay','Uruguay','Uruguay','Uruguay','Uruguai');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('UZ','Uzbekistan','UZ','',false,0,'Uzbekistan','Ouzbékistan','Usbekistan','Uzbekistan','Uzbekistan','Uzbequistão');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('VU','Vanuatu','VU','',false,0,'Vanuatu','Vanuatu','Vanuatu','Vanuatu','Vanuatu','Vanuatu');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('VE','Venezuela','VE','',false,0,'Venezuela','Venezuela','Venezuela','Venezuela','Venezuela','Venezuela');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('VN','Viet Nam','VN','',false,0,'Viet Nam','Viet Nam','Vietnam','Viet Nam','Vietnam','Viet Nam');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('VG','Virgin Islands, British','VG','',false,0,'Virgin Islands, British','Îles Vierges britanniques','Virgin Inseln, Britisch','Visiwa vya Virgin, Uingereza','Islas Vírgenes Británicas','Ilhas Virgens Britânicas');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('VI','Virgin Islands, U.S.','VI','',false,0,'Virgin Islands, U.S.','Îles Vierges américaines, États-Unis','Jungferninseln, USA','Visiwa vya Virgin, U.S.','Islas Vírgenes, EE. UU.','Ilhas Virgens, EUA');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('WF','Wallis and Futuna','WF','',false,0,'Wallis and Futuna','Wallis et Futuna','Wallis und Futuna','Wallis na Futuna','Wallis y Futuna','Wallis e Futuna');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('EH','Western Sahara','EH','',false,0,'Western Sahara','Sahara occidental','Westsahara','Sahara Magharibi','Sahara Occidental','Saara Ocidental');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('YE','Yemen','YE','',false,0,'Yemen','Yémen','Jemen','Yemen','Yemen','Iémen');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('ZM','Zambia','ZM','',false,0,'Zambia','Zambie','Sambia','Zambia','Zambia','Zâmbia');
insert into lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
	VALUES ('ZW','Zimbabwe','ZW','',false,0,'Zimbabwe','Zimbabwe','Zimbabwe','Zimbabwe','Zimbabue','Zimbábue');

INSERT INTO lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)

	VALUES (
		'XK',
		'Kosovo',
		'XK',
		null,
		false,
		0,
		'Kosovo', 'Kosovo', 'Kosovo', 'Kosovo', 'Kosovo', 'Kosovo');
INSERT INTO lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)

VALUES (
		'ME',
		'Montenegro',
		'ME',
		null,
		false,
		0,
		'Montenegro', 'Montenegro', 'Montenegro', 'Montenegro', 'Montenegro', 'Montenegro');
INSERT INTO lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
VALUES (
		'BQ',
		'Saba',
		'BQ',
		null,
		false,
		0,
		'Saba', 'Saba', 'Saba', 'Saba', 'Saba', 'Saba');
INSERT INTO lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
VALUES (
		'MF',
		'Saint Martin (France)',
		'MF',
		null,
		false,
		0,
		'Saint Martin (France)', 'Saint Martin (France)', 'Saint Martin (France)', 'Saint Martin (France)', 'Saint Martin (France)', 'Saint Martin (France)');
INSERT INTO lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
VALUES (
		'SX',
		'Sint Maarten (Netherlands)',
		'SX',
		null,
		false,
		0,
		'Sint Maarten (Netherlands)', 'Sint Maarten (Netherlands)', 'Sint Maarten (Netherlands)', 'Sint Maarten (Netherlands)', 'Sint Maarten (Netherlands)', 'Sint Maarten (Netherlands)');
INSERT INTO lookup_countrycode(
	key_, tag, ext_mapping, comment_, isdefault, preforder, en, fr, de, sw, es, pt)
VALUES (
		'SS',
		'South Sudan',
		'SS',
		null,
		false,
		0,
		'South Sudan', 'South Sudan', 'South Sudan', 'South Sudan', 'South Sudan', 'South Sudan');





