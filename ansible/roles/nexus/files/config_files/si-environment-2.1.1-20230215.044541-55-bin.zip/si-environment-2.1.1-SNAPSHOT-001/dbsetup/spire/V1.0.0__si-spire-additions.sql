--
-- PostgreSQL database dump
--

-- Dumped from database version 9.3.9
-- Dumped by pg_dump version 9.3.9
-- Started on 2021-02-02 10:57:57

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 288 (class 1259 OID 91744357)
-- Name: det_payment_records; Type: TABLE; Schema: public; Owner: gkspire; Tablespace: 
--

CREATE TABLE det_payment_records (
    record_id character varying(64) NOT NULL,
    created timestamp without time zone,
    created_by character varying(64),
    gk_id character varying(64),
    record_status character varying(16),
    replaces character varying(64),
    version_ integer,
    md_5hash character varying(255),
    ext character varying(64),
    payment_records text
);


ALTER TABLE public.det_payment_records OWNER TO gkspire;

--
-- TOC entry 187 (class 1259 OID 91743406)
-- Name: si_group_export; Type: TABLE; Schema: public; Owner: gkspire; Tablespace: 
--

CREATE TABLE si_group_export (
    record_id character varying(64) NOT NULL,
    created timestamp without time zone,
    created_by character varying(64),
    gk_id character varying(64),
    record_status character varying(16),
    replaces character varying(64),
    version_ integer,
    export_data bytea,
    confirmed_on timestamp without time zone,
    send_on timestamp without time zone
);


ALTER TABLE public.si_group_export OWNER TO gkspire;

--
-- TOC entry 188 (class 1259 OID 91743412)
-- Name: si_member_update_export; Type: TABLE; Schema: public; Owner: gkspire; Tablespace: 
--

CREATE TABLE si_member_update_export (
    record_id character varying(64) NOT NULL,
    created timestamp without time zone,
    created_by character varying(64),
    gk_id character varying(64),
    record_status character varying(16),
    replaces character varying(64),
    version_ integer,
    confirmed_on timestamp without time zone,
    export_data bytea,
    member_list bytea,
    send_on character varying(255)
);


ALTER TABLE public.si_member_update_export OWNER TO gkspire;

--
-- TOC entry 289 (class 1259 OID 91744365)
-- Name: si_payment_records; Type: TABLE; Schema: public; Owner: gkspire; Tablespace: 
--

CREATE TABLE si_payment_records (
    record_id character varying(64) NOT NULL,
    created timestamp without time zone,
    created_by character varying(64),
    gk_id character varying(64),
    record_status character varying(16),
    replaces character varying(64),
    version_ integer,
    ext character varying(64),
    other_details text,
    payment_amount double precision,
    payment_date timestamp without time zone,
    payment_detailspmt text,
    payment_mobile character varying(32),
    payment_reference character varying(128),
    payment_type character varying(8),
    payment_type_detail character varying(128)
);


ALTER TABLE public.si_payment_records OWNER TO gkspire;

--
-- TOC entry 291 (class 1259 OID 91752678)
-- Name: mibm_payment_log; Type: TABLE; Schema: public; Owner: gkspire; Tablespace: 
--

CREATE TABLE mibm_payment_log (
    sequence_id character varying(64) NOT NULL,
    date_received bigint,
    date_sent bigint,
    gkid character varying(64),
    http_endpoint character varying(256),
    http_result character varying(16),
    http_result_detail character varying(256),
    payment_reference character varying(64),
    raw_request text,
    raw_response text,
    request_result character varying(128),
    success boolean,
    transaction_id character varying(64),
    http_success boolean
);


ALTER TABLE public.mibm_payment_log OWNER TO gkspire;

--
-- TOC entry 2310 (class 2606 OID 91744364)
-- Name: det_payment_records_pkey; Type: CONSTRAINT; Schema: public; Owner: gkspire; Tablespace: 
--

ALTER TABLE ONLY det_payment_records
    ADD CONSTRAINT det_payment_records_pkey PRIMARY KEY (record_id);


--
-- TOC entry 2294 (class 2606 OID 91743949)
-- Name: si_group_export_pkey; Type: CONSTRAINT; Schema: public; Owner: gkspire; Tablespace: 
--

ALTER TABLE ONLY si_group_export
    ADD CONSTRAINT si_group_export_pkey PRIMARY KEY (record_id);


--
-- TOC entry 2302 (class 2606 OID 91743951)
-- Name: si_member_update_export_pkey; Type: CONSTRAINT; Schema: public; Owner: gkspire; Tablespace: 
--

ALTER TABLE ONLY si_member_update_export
    ADD CONSTRAINT si_member_update_export_pkey PRIMARY KEY (record_id);


--
-- TOC entry 2312 (class 2606 OID 91744372)
-- Name: si_payment_records_pkey; Type: CONSTRAINT; Schema: public; Owner: gkspire; Tablespace: 
--

ALTER TABLE ONLY si_payment_records
    ADD CONSTRAINT si_payment_records_pkey PRIMARY KEY (record_id);


--
-- TOC entry 2314 (class 2606 OID 91752685)
-- Name: mibm_payment_log_pkey; Type: CONSTRAINT; Schema: public; Owner: gkspire; Tablespace: 
--

ALTER TABLE ONLY mibm_payment_log
    ADD CONSTRAINT mibm_payment_log_pkey PRIMARY KEY (sequence_id);


--
-- TOC entry 2296 (class 2606 OID 91744107)
-- Name: uk_1pc2ybdi334dtbn7r2mp5tqac; Type: CONSTRAINT; Schema: public; Owner: gkspire; Tablespace: 
--

ALTER TABLE ONLY si_group_export
    ADD CONSTRAINT uk_1pc2ybdi334dtbn7r2mp5tqac UNIQUE (gk_id, created);


--
-- TOC entry 2298 (class 2606 OID 91744109)
-- Name: uk_3agicf4vx0wglogil9e3bwnt6; Type: CONSTRAINT; Schema: public; Owner: gkspire; Tablespace: 
--

ALTER TABLE ONLY si_group_export
    ADD CONSTRAINT uk_3agicf4vx0wglogil9e3bwnt6 UNIQUE (gk_id, created);


--
-- TOC entry 2306 (class 2606 OID 91744121)
-- Name: uk_l9975kk40dayyrs1bdj5bbgo1; Type: CONSTRAINT; Schema: public; Owner: gkspire; Tablespace: 
--

ALTER TABLE ONLY si_member_update_export
    ADD CONSTRAINT uk_l9975kk40dayyrs1bdj5bbgo1 UNIQUE (gk_id, created);


--
-- TOC entry 2308 (class 2606 OID 91744123)
-- Name: uk_sfw0ymq35m3tqjfte2da02iei; Type: CONSTRAINT; Schema: public; Owner: gkspire; Tablespace: 
--

ALTER TABLE ONLY si_member_update_export
    ADD CONSTRAINT uk_sfw0ymq35m3tqjfte2da02iei UNIQUE (gk_id, created);


--
-- TOC entry 2303 (class 1259 OID 91744172)
-- Name: uk_ama48dta6sewk2ek99nviahjj; Type: INDEX; Schema: public; Owner: gkspire; Tablespace: 
--

CREATE INDEX uk_ama48dta6sewk2ek99nviahjj ON si_member_update_export USING btree (gk_id);


--
-- TOC entry 2304 (class 1259 OID 91744181)
-- Name: uk_gke67dunosp3rtorvsc3837u5; Type: INDEX; Schema: public; Owner: gkspire; Tablespace: 
--

CREATE INDEX uk_gke67dunosp3rtorvsc3837u5 ON si_member_update_export USING btree (gk_id);


--
-- TOC entry 2299 (class 1259 OID 91744186)
-- Name: uk_i066yv5ycuvypjxmwfagm9uyj; Type: INDEX; Schema: public; Owner: gkspire; Tablespace: 
--

CREATE INDEX uk_i066yv5ycuvypjxmwfagm9uyj ON si_group_export USING btree (gk_id);


--
-- TOC entry 2300 (class 1259 OID 91744200)
-- Name: uk_te9y6qr0lcl1rjl1tm80bih9s; Type: INDEX; Schema: public; Owner: gkspire; Tablespace: 
--

CREATE INDEX uk_te9y6qr0lcl1rjl1tm80bih9s ON si_group_export USING btree (gk_id);


-- Completed on 2021-02-02 10:57:57

--
-- PostgreSQL database dump complete
--

