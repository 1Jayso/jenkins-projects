-- add support to handle operators

ALTER TABLE necto_external_operators
   ADD COLUMN status character varying(8) DEFAULT '00';
COMMENT ON COLUMN necto_external_operators.status
  IS 'EXOP_STATUS';

-- ALTER TABLE necto_external_operators
--    ADD COLUMN lastchange timestamp without time zone;

CREATE INDEX necto_external_operators_idx1
  ON necto_external_operators
  USING btree
  (lastchange);

CREATE INDEX necto_external_operators_idx2
  ON necto_external_operators
  USING btree
  (status);

CREATE INDEX necto_external_operators_idx3
  ON necto_external_operators
  USING btree
  (lastchange,status);




CREATE TABLE si_operator_records
(
  record_id character varying(64) NOT NULL,
  created timestamp without time zone,
  created_by character varying(64),
  gk_id character varying(64),
  record_status character varying(16),
  replaces character varying(64),
  version_ integer,
  ext character varying(64),
  bio_hash_data bytea,
  date_of_entry timestamp without time zone,
  date_of_exit timestamp without time zone,
  last_change timestamp without time zone,
  operator_details text,
  pw character varying(64),
  role character varying(8),
  status character varying(8),
  CONSTRAINT si_operator_records_pkey PRIMARY KEY (record_id)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE si_operator_records
  OWNER TO gkspire;


CREATE INDEX si_operator_records_idx1
  ON si_operator_records
  USING btree
  (last_change,status);



CREATE UNIQUE INDEX si_operator_records_idx2
  ON si_operator_records
  USING btree
  (gk_id);


CREATE TABLE det_operator_records
(
  record_id character varying(64) NOT NULL,
  created timestamp without time zone,
  created_by character varying(64),
  gk_id character varying(64),
  record_status character varying(16),
  replaces character varying(64),
  version_ integer,
  md_5hash character varying(255),
  ext character varying(64),
  operator_records text,
  CONSTRAINT det_operator_records_pkey PRIMARY KEY (record_id)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE det_operator_records
  OWNER TO gkspire;

-- missed repair
CREATE SCHEMA si_repair
  AUTHORIZATION gkspire;

GRANT ALL ON SCHEMA si_repair TO gkspire;
GRANT ALL ON SCHEMA si_repair TO public;

CREATE TABLE si_repair.reindex_groups
(
  group_id character varying(255) NOT NULL,
  processor integer,
  CONSTRAINT reindx_pk PRIMARY KEY (group_id)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE si_repair.reindex_groups
  OWNER TO gkspire;

CREATE INDEX reindex_groups_idx1
  ON si_repair.reindex_groups
  USING btree
  (processor);
