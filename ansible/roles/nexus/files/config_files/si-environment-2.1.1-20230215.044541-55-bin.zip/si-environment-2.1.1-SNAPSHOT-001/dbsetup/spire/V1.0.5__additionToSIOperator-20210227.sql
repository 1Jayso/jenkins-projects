ALTER TABLE public.si_operator_records
    ADD COLUMN biometric_subject bytea;
