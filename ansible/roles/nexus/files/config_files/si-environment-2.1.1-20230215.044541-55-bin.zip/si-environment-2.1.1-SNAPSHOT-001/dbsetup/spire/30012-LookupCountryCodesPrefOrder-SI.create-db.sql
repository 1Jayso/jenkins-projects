
-- Sample mapping
Update lookup_countrycode set isdefault = true, ext_mapping='01' where key_ = 'TZ' ;
Update lookup_countrycode set preforder = 1, ext_mapping='02' where key_ = 'KE';
Update lookup_countrycode set preforder = 2, ext_mapping='03' where key_ = 'UG';
Update lookup_countrycode set preforder = 3, ext_mapping='04' where key_ = 'RW';
Update lookup_countrycode set preforder = 4, ext_mapping='05' where key_ = 'BI';
Update lookup_countrycode set preforder = 5, ext_mapping='06' where key_ = 'MW';
Update lookup_countrycode set preforder = 6, ext_mapping='07' where key_ = 'MZ';
