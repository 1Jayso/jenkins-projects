CREATE SCHEMA IF NOT EXISTS si
    AUTHORIZATION gkspire;

GRANT ALL ON SCHEMA si TO PUBLIC;

GRANT ALL ON SCHEMA si TO gkspire;


--
-- TOC entry 311 (class 1259 OID 93647467)
-- Name: afis_submitted_data; Type: TABLE; Schema: si; Owner: gkspire
--

CREATE TABLE IF NOT EXISTS si.afis_submitted_data (
    voterid character varying(64) NOT NULL,
    birthdate character varying(255),
    birthdateknown character varying(255),
    countryofbirth character varying(255),
    firstname character varying(255),
    gender character varying(255),
    maritalstatus character varying(255),
    middlename character varying(255),
    mobileno character varying(255),
    nationalid character varying(255),
    nationality character varying(255),
    postaladdress character varying(255),
    registration_center character varying(255),
    registration_date character varying(255),
    registration_officer_id character varying(255),
    registration_officer_name character varying(255),
    registration_station character varying(255),
    residentialward character varying(255),
    sn integer NOT NULL,
    surname character varying(255),
    voting_center_code character varying(255),
    CONSTRAINT afis_submitted_data_pkey PRIMARY KEY (voterid)
);


ALTER TABLE si.afis_submitted_data OWNER TO gkspire;

--
-- TOC entry 306 (class 1259 OID 93647427)
-- Name: si_import_log_groups; Type: TABLE; Schema: si; Owner: gkspire
--

CREATE TABLE IF NOT EXISTS si.si_import_log_groups (
    record_id character varying(64) NOT NULL,
    created timestamp without time zone,
    ext character varying(64),
    groupid character varying(128),
    officer_id character varying(256),
    officer_detail text,
    original_text bytea,
    process_log text,
    station_id character varying(256),
    station_detail text,
    registration_officeid character varying(64),
    registration_office_detail text,
    result character varying(32),
    version_ integer,
    end_loading bigint NOT NULL,
    error_text character varying(255),
    loading_time_biographics bigint NOT NULL,
    loading_time_biometrics bigint NOT NULL,
    loading_time_facial bigint NOT NULL,
    number_threads_used integer NOT NULL,
    processing_timespire bigint NOT NULL,
    start_loading bigint NOT NULL,
    subjects_attempted integer NOT NULL,
    subjects_planned integer NOT NULL,
    success boolean NOT NULL,
    total_failed integer NOT NULL,
    total_fatal integer NOT NULL,
    total_success integer NOT NULL,
    virtual_person character varying(64),
    CONSTRAINT si_import_log_groups_pkey PRIMARY KEY (record_id)
);


ALTER TABLE si.si_import_log_groups OWNER TO gkspire;

--
-- TOC entry 307 (class 1259 OID 93647435)
-- Name: si_import_log_persons; Type: TABLE; Schema: si; Owner: gkspire
--

CREATE TABLE IF NOT EXISTS si.si_import_log_persons (
    record_id character varying(64) NOT NULL,
    created timestamp without time zone,
    ext character varying(64),
    groupid character varying(128),
    officer_id character varying(256),
    officer_detail text,
    original_text bytea,
    process_log text,
    station_id character varying(256),
    station_detail text,
    registration_officeid character varying(64),
    registration_office_detail text,
    result character varying(32),
    version_ integer,
    personuuid character varying(64),
    CONSTRAINT si_import_log_persons_pkey PRIMARY KEY (record_id)
);


ALTER TABLE si.si_import_log_persons OWNER TO gkspire;

--
-- TOC entry 312 (class 1259 OID 93647475)
-- Name: sisubjects_of_interest; Type: TABLE; Schema: si; Owner: gkspire
--

CREATE TABLE IF NOT EXISTS si.sisubjects_of_interest (
    personuuid character varying(64) NOT NULL,
    biographics_done integer,
    biometrics_done integer,
    civil_id integer,
    elect_id integer,
    face_done integer,
    faceid character varying(255),
    fpid character varying(255),
    group_id character varying(64),
    CONSTRAINT sisubjects_of_interest_pkey PRIMARY KEY (personuuid)
);


ALTER TABLE si.sisubjects_of_interest OWNER TO gkspire;

--
-- TOC entry 308 (class 1259 OID 93647443)
-- Name: prim_adj_profile_temp; Type: TABLE; Schema: si; Owner: gkspire
--

CREATE TABLE IF NOT EXISTS si.prim_adj_profile_temp (
    record_id character varying(64) NOT NULL,
    created timestamp without time zone,
    created_by character varying(64),
    gk_id character varying(64),
    record_status character varying(16),
    replaces character varying(64),
    version_ integer,
    adjudication_status character varying(255),
    bio_hash character varying(255),
    comment_ character varying(255),
    date_duplicated timestamp without time zone,
    date_entered timestamp without time zone,
    eligibility_change_id character varying(64),
    external_process_id character varying(64),
    last_date_duplicated timestamp without time zone,
    process_error_code character varying(255),
    process_status character varying(255),
    CONSTRAINT prim_adj_profile_temp_pkey PRIMARY KEY (record_id)
);


ALTER TABLE si.prim_adj_profile_temp OWNER TO gkspire;

--
-- TOC entry 309 (class 1259 OID 93647451)
-- Name: prim_eligibility_profile_temp; Type: TABLE; Schema: si; Owner: gkspire
--

CREATE TABLE IF NOT EXISTS si.prim_eligibility_profile_temp (
    record_id character varying(64) NOT NULL,
    created timestamp without time zone,
    created_by character varying(64),
    gk_id character varying(64),
    record_status character varying(16),
    replaces character varying(64),
    version_ integer,
    current_status character varying(255),
    date_last_changed timestamp without time zone,
    other_properties text,
    CONSTRAINT prim_eligibility_profile_temp_pkey PRIMARY KEY (record_id)
);


ALTER TABLE si.prim_eligibility_profile_temp OWNER TO gkspire;
