

--
-- TOC entry 319 (class 1259 OID 90908475)
-- Name: sys_crd_card_sending_results; Type: TABLE; Schema: public; Owner: gkspire; Tablespace: 
--

CREATE TABLE sys_crd_card_sending_results (
    record_id character varying(64) NOT NULL,
    created timestamp without time zone,
    created_by character varying(64),
    gk_id character varying(64),
    record_status character varying(16),
    replaces character varying(64),
    version_ integer,
    ext character varying(64),
    batch_size integer,
    cards_processed text,
    final_status character varying(255),
    finished timestamp without time zone,
    number_attempted integer,
    number_attempts integer,
    number_failed integer,
    number_no_response integer,
    number_serious_errors integer,
    number_successfull integer,
    session_initiator character varying(255),
    started timestamp without time zone
);


ALTER TABLE public.sys_crd_card_sending_results OWNER TO gkspire;

--
-- TOC entry 320 (class 1259 OID 90908483)
-- Name: sys_crd_cards_current; Type: TABLE; Schema: public; Owner: gkspire; Tablespace: 
--

CREATE TABLE sys_crd_cards_current (
    record_id character varying(64) NOT NULL,
    created timestamp without time zone,
    created_by character varying(64),
    gk_id character varying(64),
    record_status character varying(16),
    replaces character varying(64),
    version_ integer,
    ext character varying(64),
    archived boolean,
    image_data bytea,
    confirmed_upload timestamp without time zone,
    last_changed_date timestamp without time zone,
    last_check_date timestamp without time zone,
    md5hash character varying(255),
    transaction_type character varying(255),
    replaced boolean,
    card_type character varying(8)
);


ALTER TABLE public.sys_crd_cards_current OWNER TO gkspire;

--
-- TOC entry 321 (class 1259 OID 90908491)
-- Name: sys_crd_cards_replaced; Type: TABLE; Schema: public; Owner: gkspire; Tablespace: 
--

CREATE TABLE sys_crd_cards_replaced (
    record_id character varying(64) NOT NULL,
    created timestamp without time zone,
    created_by character varying(64),
    gk_id character varying(64),
    record_status character varying(16),
    replaces character varying(64),
    version_ integer,
    ext character varying(64),
    archived boolean,
    image_data bytea,
    confirmed_upload timestamp without time zone,
    last_changed_date timestamp without time zone,
    last_check_date timestamp without time zone,
    md5hash character varying(255),
    transaction_type character varying(255),
    replaced boolean,
    card_type character varying(8)
);


ALTER TABLE public.sys_crd_cards_replaced OWNER TO gkspire;

--
-- TOC entry 322 (class 1259 OID 90908499)
-- Name: sys_crd_exportedcard_responses; Type: TABLE; Schema: public; Owner: gkspire; Tablespace: 
--

CREATE TABLE sys_crd_exportedcard_responses (
    record_id character varying(64) NOT NULL,
    created timestamp without time zone,
    created_by character varying(64),
    gk_id character varying(64),
    record_status character varying(16),
    replaces character varying(64),
    version_ integer,
    ext character varying(64),
    card_reference character varying(255),
    dismiss boolean,
    response text,
    result_status character varying(32),
    successful boolean
);


ALTER TABLE public.sys_crd_exportedcard_responses OWNER TO gkspire;

--
-- TOC entry 2441 (class 2606 OID 90908482)
-- Name: sys_crd_card_sending_results_pkey; Type: CONSTRAINT; Schema: public; Owner: gkspire; Tablespace: 
--

ALTER TABLE ONLY sys_crd_card_sending_results
    ADD CONSTRAINT sys_crd_card_sending_results_pkey PRIMARY KEY (record_id);


--
-- TOC entry 2446 (class 2606 OID 90908490)
-- Name: sys_crd_cards_current_pkey; Type: CONSTRAINT; Schema: public; Owner: gkspire; Tablespace: 
--

ALTER TABLE ONLY sys_crd_cards_current
    ADD CONSTRAINT sys_crd_cards_current_pkey PRIMARY KEY (record_id);


--
-- TOC entry 2458 (class 2606 OID 90908498)
-- Name: sys_crd_cards_replaced_pkey; Type: CONSTRAINT; Schema: public; Owner: gkspire; Tablespace: 
--

ALTER TABLE ONLY sys_crd_cards_replaced
    ADD CONSTRAINT sys_crd_cards_replaced_pkey PRIMARY KEY (record_id);


--
-- TOC entry 2466 (class 2606 OID 90908506)
-- Name: sys_crd_exportedcard_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: gkspire; Tablespace: 
--

ALTER TABLE ONLY sys_crd_exportedcard_responses
    ADD CONSTRAINT sys_crd_exportedcard_responses_pkey PRIMARY KEY (record_id);


--
-- TOC entry 2448 (class 2606 OID 90908513)
-- Name: uk_14ykipu90ed2ung0jhi1fgjsh; Type: CONSTRAINT; Schema: public; Owner: gkspire; Tablespace: 
--

ALTER TABLE ONLY sys_crd_cards_current
    ADD CONSTRAINT uk_14ykipu90ed2ung0jhi1fgjsh UNIQUE (md5hash);


--
-- TOC entry 2450 (class 2606 OID 90908517)
-- Name: uk_41h9l6d9unin5ofam0303nddg; Type: CONSTRAINT; Schema: public; Owner: gkspire; Tablespace: 
--

ALTER TABLE ONLY sys_crd_cards_current
    ADD CONSTRAINT uk_41h9l6d9unin5ofam0303nddg UNIQUE (gk_id, last_check_date);


--
-- TOC entry 2460 (class 2606 OID 90908523)
-- Name: uk_78ldhkj2vm4rthwgcl8bmopn0; Type: CONSTRAINT; Schema: public; Owner: gkspire; Tablespace: 
--

ALTER TABLE ONLY sys_crd_cards_replaced
    ADD CONSTRAINT uk_78ldhkj2vm4rthwgcl8bmopn0 UNIQUE (gk_id, last_changed_date);


--
-- TOC entry 2453 (class 2606 OID 90908511)
-- Name: uk_a9l42w46uvsdtorqnkhe1t4ke; Type: CONSTRAINT; Schema: public; Owner: gkspire; Tablespace: 
--

ALTER TABLE ONLY sys_crd_cards_current
    ADD CONSTRAINT uk_a9l42w46uvsdtorqnkhe1t4ke UNIQUE (gk_id);


--
-- TOC entry 2463 (class 2606 OID 90908521)
-- Name: uk_d3col40iq30k9ixw6k5x0gulj; Type: CONSTRAINT; Schema: public; Owner: gkspire; Tablespace: 
--

ALTER TABLE ONLY sys_crd_cards_replaced
    ADD CONSTRAINT uk_d3col40iq30k9ixw6k5x0gulj UNIQUE (md5hash);


--
-- TOC entry 2456 (class 2606 OID 90908515)
-- Name: uk_t5rr3utlmn4p51n7n82wrjyc0; Type: CONSTRAINT; Schema: public; Owner: gkspire; Tablespace: 
--

ALTER TABLE ONLY sys_crd_cards_current
    ADD CONSTRAINT uk_t5rr3utlmn4p51n7n82wrjyc0 UNIQUE (gk_id, last_changed_date);


--
-- TOC entry 2442 (class 1259 OID 90908508)
-- Name: uk_4nv5dmy5mfaqc41s5p92jg29y; Type: INDEX; Schema: public; Owner: gkspire; Tablespace: 
--

CREATE INDEX uk_4nv5dmy5mfaqc41s5p92jg29y ON sys_crd_card_sending_results USING btree (final_status);


--
-- TOC entry 2443 (class 1259 OID 90908509)
-- Name: uk_667nb53b3njdgl5536g4329i7; Type: INDEX; Schema: public; Owner: gkspire; Tablespace: 
--

CREATE INDEX uk_667nb53b3njdgl5536g4329i7 ON sys_crd_card_sending_results USING btree (started);


--
-- TOC entry 2461 (class 1259 OID 90908524)
-- Name: uk_91ly76x3ex7jmpatp9dwh0d9g; Type: INDEX; Schema: public; Owner: gkspire; Tablespace: 
--

CREATE INDEX uk_91ly76x3ex7jmpatp9dwh0d9g ON sys_crd_cards_replaced USING btree (gk_id);


--
-- TOC entry 2451 (class 1259 OID 90908519)
-- Name: uk_937ljb6ycabh6u3qi607o1aav; Type: INDEX; Schema: public; Owner: gkspire; Tablespace: 
--

CREATE INDEX uk_937ljb6ycabh6u3qi607o1aav ON sys_crd_cards_current USING btree (archived, last_changed_date);


--
-- TOC entry 2444 (class 1259 OID 90908507)
-- Name: uk_au84t7lya6ukg60yqgub2m173; Type: INDEX; Schema: public; Owner: gkspire; Tablespace: 
--

CREATE INDEX uk_au84t7lya6ukg60yqgub2m173 ON sys_crd_card_sending_results USING btree (session_initiator);


--
-- TOC entry 2467 (class 1259 OID 90908526)
-- Name: uk_bf9h7y97uqbc95hfh4e249evx; Type: INDEX; Schema: public; Owner: gkspire; Tablespace: 
--

CREATE INDEX uk_bf9h7y97uqbc95hfh4e249evx ON sys_crd_exportedcard_responses USING btree (gk_id);


--
-- TOC entry 2468 (class 1259 OID 90908528)
-- Name: uk_bwtnqdwfsrsdqtoxbb6dcfnox; Type: INDEX; Schema: public; Owner: gkspire; Tablespace: 
--

CREATE INDEX uk_bwtnqdwfsrsdqtoxbb6dcfnox ON sys_crd_exportedcard_responses USING btree (created);


--
-- TOC entry 2454 (class 1259 OID 90908518)
-- Name: uk_g1jw3e5akv0siu40ssyu0su1b; Type: INDEX; Schema: public; Owner: gkspire; Tablespace: 
--

CREATE INDEX uk_g1jw3e5akv0siu40ssyu0su1b ON sys_crd_cards_current USING btree (created);


--
-- TOC entry 2464 (class 1259 OID 90908525)
-- Name: uk_nmrh3ouf9bcagd9cy06yprlo2; Type: INDEX; Schema: public; Owner: gkspire; Tablespace: 
--

CREATE INDEX uk_nmrh3ouf9bcagd9cy06yprlo2 ON sys_crd_cards_replaced USING btree (created);


--
-- TOC entry 2469 (class 1259 OID 90908527)
-- Name: uk_pyw6lg4i9wwdbm3lid8aeowy7; Type: INDEX; Schema: public; Owner: gkspire; Tablespace: 
--

CREATE INDEX uk_pyw6lg4i9wwdbm3lid8aeowy7 ON sys_crd_exportedcard_responses USING btree (card_reference);


-- Completed on 2021-03-03 12:03:59

--
-- PostgreSQL database dump complete
--

