--
-- PostgreSQL database dump
--

-- Dumped from database version 9.3.9
-- Dumped by pg_dump version 9.3.9
-- Started on 2021-02-07 11:40:08

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 298 (class 1259 OID 91752871)
-- Name: det_license_records; Type: TABLE; Schema: public; Owner: gkspire; Tablespace: 
--

CREATE TABLE det_license_records (
    record_id character varying(64) NOT NULL,
    created timestamp without time zone,
    created_by character varying(64),
    gk_id character varying(64),
    record_status character varying(16),
    replaces character varying(64),
    version_ integer,
    md_5hash character varying(255),
    ext character varying(64),
    license_records text
);


ALTER TABLE public.det_license_records OWNER TO gkspire;

--
-- TOC entry 299 (class 1259 OID 91752879)
-- Name: si_license_records; Type: TABLE; Schema: public; Owner: gkspire; Tablespace: 
--

CREATE TABLE si_license_records (
    record_id character varying(64) NOT NULL,
    created timestamp without time zone,
    created_by character varying(64),
    gk_id character varying(64),
    record_status character varying(16),
    replaces character varying(64),
    version_ integer,
    ext character varying(64),
    expiration_date timestamp without time zone,
    holder_public_person_id character varying(32),
    license_format_option character varying(8),
    license_id character varying(255),
    license_number character varying(32),
    license_type_option character varying(8),
    other_details text,
    license_detailspmt text,
    verified_by character varying(32)
);


ALTER TABLE public.si_license_records OWNER TO gkspire;

--
-- TOC entry 2302 (class 2606 OID 91752878)
-- Name: det_license_records_pkey; Type: CONSTRAINT; Schema: public; Owner: gkspire; Tablespace: 
--

ALTER TABLE ONLY det_license_records
    ADD CONSTRAINT det_license_records_pkey PRIMARY KEY (record_id);


--
-- TOC entry 2304 (class 2606 OID 91752886)
-- Name: si_license_records_pkey; Type: CONSTRAINT; Schema: public; Owner: gkspire; Tablespace: 
--

ALTER TABLE ONLY si_license_records
    ADD CONSTRAINT si_license_records_pkey PRIMARY KEY (record_id);


-- Completed on 2021-02-07 11:40:08

--
-- PostgreSQL database dump complete
--

CREATE INDEX si_license_record_idx1
   ON si_license_records (license_number ASC NULLS LAST);

CREATE INDEX si_license_record_idx2
   ON si_license_records (license_id ASC NULLS LAST);

CREATE INDEX si_license_record_idx3
   ON si_license_records (holder_public_person_id ASC NULLS LAST);