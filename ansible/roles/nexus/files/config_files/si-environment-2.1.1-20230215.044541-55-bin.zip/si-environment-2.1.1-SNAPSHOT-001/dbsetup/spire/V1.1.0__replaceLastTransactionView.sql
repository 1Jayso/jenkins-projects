DROP VIEW if exists public.sys_view_last_transaction;

CREATE OR REPLACE VIEW public.sys_view_last_transaction
 AS
 SELECT p.gk_id,
    to_timestamp((s_l.version / 1000)::double precision) AS last_activity,
    p_e.current_status,
    p_e.date_primary_review,
    p_e.date_secondary_review,
	case when p_b is null then 0::integer else p_b.processed end as processed,
    card.last_changed_date,
    card.md5hash,
    card.last_check_date
   FROM gk_person p
     JOIN prim_eligibility_profile p_e ON p.eligibility_profile_ref::text = p_e.record_id::text
     LEFT JOIN prim_biometric_profile p_b ON p.biometric_profile_ref::text = p_b.record_id::text
     JOIN sys_search_log s_l ON p.gk_id::text = s_l.id::text AND NOT s_l.isgroup
     JOIN prim_eligibility_profile el ON p.eligibility_profile_ref::text = el.record_id::text
     LEFT JOIN sys_crd_cards_current card ON p.gk_id::text = card.gk_id::text;

ALTER TABLE public.sys_view_last_transaction
    OWNER TO gkspire;
