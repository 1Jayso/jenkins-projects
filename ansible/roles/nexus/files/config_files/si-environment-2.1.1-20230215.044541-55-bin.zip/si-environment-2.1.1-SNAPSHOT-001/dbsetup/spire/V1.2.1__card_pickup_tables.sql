-- Table: public.det_cardpickup_records

-- DROP TABLE public.det_cardpickup_records;

CREATE TABLE if not exists public.det_cardpickup_records
(
    record_id character varying(64) COLLATE pg_catalog."default" NOT NULL,
    created timestamp without time zone,
    created_by character varying(64) COLLATE pg_catalog."default",
    gk_id character varying(64) COLLATE pg_catalog."default",
    record_status character varying(16) COLLATE pg_catalog."default",
    replaces character varying(64) COLLATE pg_catalog."default",
    version_ integer,
    md_5hash character varying(255) COLLATE pg_catalog."default",
    ext character varying(64) COLLATE pg_catalog."default",
    card_pickups text COLLATE pg_catalog."default",
    CONSTRAINT det_cardpickup_records_pkey PRIMARY KEY (record_id)
)
WITH (
    OIDS = FALSE
);


ALTER TABLE public.det_cardpickup_records
    OWNER to gkspire;

-- Table: public.si_card_pickup_log

-- DROP TABLE public.si_card_pickup_log;


CREATE TABLE IF NOT EXISTS public.si_card_pickup_log
(
    record_id character varying(64) COLLATE pg_catalog."default" NOT NULL,
    created timestamp without time zone,
    created_by character varying(64) COLLATE pg_catalog."default",
    gk_id character varying(64) COLLATE pg_catalog."default",
    record_status character varying(16) COLLATE pg_catalog."default",
    replaces character varying(64) COLLATE pg_catalog."default",
    version_ integer,
    ext character varying(64) COLLATE pg_catalog."default",
    card_serial_number character varying(64) COLLATE pg_catalog."default",
    card_record_id character varying(64) COLLATE pg_catalog."default",
    center_id character varying(64) COLLATE pg_catalog."default",
    officer_id character varying(64) COLLATE pg_catalog."default",
    p_first_name character varying(64) COLLATE pg_catalog."default",
    p_identity character varying(64) COLLATE pg_catalog."default",
    p_identity_type character varying(32) COLLATE pg_catalog."default",
    p_last_name character varying(64) COLLATE pg_catalog."default",
    pickup_by_owner boolean,
    pickup_date timestamp without time zone,
    pickup_detailspmt text COLLATE pg_catalog."default",
    station_id character varying(64) COLLATE pg_catalog."default",
    verified boolean,
    CONSTRAINT si_card_pickup_log_pkey PRIMARY KEY (record_id)
)
WITH (
    OIDS = FALSE
);


ALTER TABLE public.si_card_pickup_log
    OWNER to gkspire;
	


CREATE INDEX IF NOT EXISTS si_card_pickup_log_idx1 
ON public.si_card_pickup_log (gk_id,card_serial_number);