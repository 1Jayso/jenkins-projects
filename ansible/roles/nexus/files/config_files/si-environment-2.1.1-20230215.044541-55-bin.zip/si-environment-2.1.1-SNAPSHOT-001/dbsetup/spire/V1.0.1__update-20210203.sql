ALTER TABLE mibm_payment_log
   ALTER COLUMN request_result TYPE text;

ALTER TABLE mibm_payment_log
   ALTER COLUMN http_result_detail TYPE text;