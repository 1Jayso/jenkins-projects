-- Table: public.synch_pending
-- required to run synchronizer

DROP TABLE if exists public.synch_pending cascade;

CREATE TABLE public.synch_pending
(
    record_id character varying(64)  NOT NULL,
    transaction_record_id character varying(64) ,
    group_id character varying(64) ,
    gk_id character varying(64) ,
    isgroup boolean,
    created timestamp without time zone,
    transactiontype character varying(32) ,
    member_id character varying(64) ,
    newrecord boolean,
    confirmed timestamp without time zone,
    CONSTRAINT synch_pen_pk PRIMARY KEY (record_id)
);

ALTER TABLE public.synch_pending
    OWNER to gkspire;


-- Index: synch_pen_2

-- DROP INDEX public.synch_pen_2;

CREATE INDEX synch_pen_2
    ON public.synch_pending 
    (created ASC NULLS LAST)
    ;

--ensure we have the current set 
Insert into synch_pending 
select 
record_id, transaction_record_id, group_id, gk_id, isgroup, created, transactiontype, member_id, newrecord, null
 from sys_pending_export;


CREATE OR REPLACE FUNCTION synch_recording()
  RETURNS TRIGGER 
  LANGUAGE PLPGSQL
  AS
$$
BEGIN
	
		 INSERT INTO synch_pending 
		 (
	record_id, transaction_record_id, group_id, gk_id, isgroup, created, transactiontype, member_id, newrecord, confirmed)
		 VALUES(
		 NEW.record_id, 
		 NEW.transaction_record_id, 
		 NEW.group_id, 
		 NEW.gk_id, 
		 NEW.isgroup, 
		 NEW.created, 
		 NEW.transactiontype, 
		 NEW.member_id, 
		 NEW.newrecord, 
		 null
		 );
	

	RETURN NEW;
END;
$$
;
DROP TRIGGER IF EXISTS new_pending_to_synch on sys_pending_export cascade;

CREATE  TRIGGER new_pending_to_synch
  AFTER INSERT
  ON sys_pending_export
  FOR EACH ROW
  EXECUTE PROCEDURE synch_recording();

Drop TABLE if exists public.synch_pending_processed cascade;

CREATE TABLE public.synch_pending_processed
(
    record_id character varying(64) NOT NULL,
    transaction_record_id character varying(64) ,
    group_id character varying(64) ,
    gk_id character varying(64) ,
    isgroup boolean,
    created timestamp without time zone,
    transactiontype character varying(32) ,
    member_id character varying(64) ,
    newrecord boolean,
    confirmed timestamp without time zone,
    CONSTRAINT synch_pen_proc_pk PRIMARY KEY (record_id)
);

ALTER TABLE public.synch_pending_processed
    OWNER to gkspire;

CREATE INDEX synch_pending_processed_idx1
    ON public.synch_pending_processed 
    (created asc, group_id , gk_id, confirmed desc NULLS LAST );
-- Index: synch_pen_2

-- DROP INDEX public.synch_pen_2;




drop  materialized view if exists sys_pending_export_snapshot cascade;
	drop materialized view if exists synch_pending_export_snapshot cascade;
	drop materialized view if exists synch_pending_snapshot cascade;
	
	Create  materialized view if not exists synch_pending_snapshot as 
Select p.* from synch_pending_processed p where p.confirmed is NULL
		union ALL
		(SELECT 
		o.* FROM synch_pending o where o.created <= NOW() order by created asc limit 100)
WITH NO DATA;
--		SELECT o.* FROM synch_pending o where o.created <= NOW() order by created asc limit 5000; 
CREATE INDEX synch_pending_snapshot_idx1
    ON public.synch_pending_snapshot 
    (created asc, group_id , gk_id );
CREATE UNIQUE INDEX synch_pending_snapshot_uidx1
    ON public.synch_pending_snapshot 
    (record_id);

drop view if exists public.synch_group_summary;
create view public.synch_group_summary
as
select s.group_id, s.gk_id, 

(extract(epoch from min(s.created) at time zone 'UTC')*1000) :: bigint as oldest,
(extract(epoch from max(s.created) at time zone 'UTC')*1000) :: bigint as newest,
max(p.facial_ref) as face,
max(p.biometric_profile_ref) as biometrics,
count(*)::bigint as num_records
	from public.synch_pending_snapshot s
	left join gk_person p on (s.gk_id is not null and s.gk_id = p.gk_id)
	group by s.group_id, s.gk_id
	order by min(s.created) asc, s.group_id, s.gk_id nulls first;


drop view if exists public.synch_group_summary_full;
create view public.synch_group_summary_full
as
select s.group_id, s.gk_id,s.oldest,s.newest,
f.format::varchar(16) as facial_format,
case when f.created is null then 0 else (extract(epoch from f.created at time zone 'UTC')*1000) end :: bigint as facial_date,
	f.image_data as facial,
case when b.created is null then 0 else (extract(epoch from b.created at time zone 'UTC')*1000) end :: bigint as biometric_date,
	b.biometric_profile as biometric,
	g.summary_content as groupRecord,
	m.summary_content as memberRecord,
	s.num_records
	from synch_group_summary s
	left join prim_facial_profile f on (s.face is not null and s.face = f.record_id)
	left join prim_biometric_profile b on (s.biometrics is not null and s.biometrics = b.record_id)
	left join sys_search_log m on (s.gk_id is not null and not m.isgroup  and s.gk_id = m.id)
	left join sys_search_log g on (s.gk_id is null and g.isgroup and s.group_id = g.id)
order by s.oldest asc
;

drop function if exists public.start_synch();

CREATE OR REPLACE FUNCTION public.start_synch(
	)
RETURNS bigint
--RETURNS TABLE(group_id character varying(64), gk_id character varying(64), oldest bigint, newest bigint, num_records bigint)
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
mycount bigint ;
SQLQuery text;
  SQLQueries text[] := array[
    
	'Refresh materialized view 	synch_pending_snapshot;'
	,	
	'INSERT INTO synch_pending_processed
    		select s.* from	synch_pending_snapshot s 
left join synch_pending_processed p on p.record_id = s.record_id 
where p.group_id is null;'
,
'delete from     synch_pending where record_id in (select record_id from synch_pending_snapshot);'

    ];
BEGIN
  /* Iterate our array */
  FOREACH SQLQuery IN ARRAY SQLQueries
  LOOP
    /* Start transaction block */
      EXECUTE SQLQuery;
     
    
  END LOOP;
  select count(*) into mycount from synch_group_summary;
 
  return  mycount; 
  --RETURN QUERY select *  from synch_group_summary;
END;
$BODY$;

ALTER FUNCTION public.start_synch()
    OWNER TO gkspire;
drop function if exists public.confirm_synch_gk(groupid varchar, gkid varchar);
drop function if exists public.confirm_synch_group(groupid varchar);


