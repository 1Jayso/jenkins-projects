﻿-- UG : New User Roles
INSERT INTO public.SEC_ROLES (NAME, PERMISSIONS) VALUES ('system_monitoring', 'SYSTEM_MONITORING:VIEW');
