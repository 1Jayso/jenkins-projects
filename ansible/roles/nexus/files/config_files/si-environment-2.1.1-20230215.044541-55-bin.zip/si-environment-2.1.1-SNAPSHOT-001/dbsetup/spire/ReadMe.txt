Naming convention:
V1.0.X__<description>.sql

Where 
- V stands for db script to be executed 
- 1 for the current Simba product
- 0 for spire database
- X numeric, ascending sequence of files


ONCE A FILE IS COMMITTED TO SVN THE CONTENT SHALL NEVER BE CHANGED !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!




