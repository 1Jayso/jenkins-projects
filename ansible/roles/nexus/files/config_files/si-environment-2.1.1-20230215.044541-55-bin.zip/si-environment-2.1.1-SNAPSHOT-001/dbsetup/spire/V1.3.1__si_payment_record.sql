
--
-- TOC entry 318 (class 1259 OID 182358)
-- Name: si_payment_record; Type: TABLE; Schema: public; Owner: gkspire
--

CREATE TABLE public.si_payment_record (
    record_id character varying(64) NOT NULL,
    created timestamp without time zone,
    created_by character varying(64),
    gk_id character varying(64),
    record_status character varying(16),
    replaces character varying(64),
    version_ integer,
    ext character varying(64),
    history_column text,
    other_properties text,
    pay_amount integer,
    pay_amount_required integer,
    pay_cancelled boolean,
    pay_confirmed_officerid character varying(64),
    pay_date timestamp without time zone,
    pay_date_confirmed timestamp without time zone,
    pay_details text,
    pay_is_prepay boolean,
    pay_mobile character varying(64),
    pay_officerid character varying(64),
    pay_payment_slip_doc character varying(64),
    pay_prepay_balance integer,
    pay_provider character varying(64),
    pay_reason character varying(64),
    pay_ref character varying(64),
    pay_stationid character varying(64),
    pay_status boolean,
    pay_statusmessage character varying(255),
    pay_trans character varying(64),
    pay_type character varying(64),
    pay_type_detail character varying(255),
    payment_site character varying(64),
    prepaid_uuid character varying(64)
);


ALTER TABLE public.si_payment_record OWNER TO gkspire;

--
-- TOC entry 3425 (class 2606 OID 182365)
-- Name: si_payment_record si_payment_record_pkey; Type: CONSTRAINT; Schema: public; Owner: gkspire
--

ALTER TABLE ONLY public.si_payment_record
    ADD CONSTRAINT si_payment_record_pkey PRIMARY KEY (record_id);


--
-- TOC entry 3426 (class 1259 OID 182382)
-- Name: uk_qvv3619tpo4nxe2knolp9w3le; Type: INDEX; Schema: public; Owner: gkspire
--

CREATE INDEX uk_qvv3619tpo4nxe2knolp9w3le ON public.si_payment_record USING btree (gk_id);




