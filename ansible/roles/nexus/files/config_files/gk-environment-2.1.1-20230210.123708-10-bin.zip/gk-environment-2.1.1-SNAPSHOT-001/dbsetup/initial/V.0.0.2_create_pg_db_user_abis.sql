CREATE ROLE abis_controller WITH SUPERUSER LOGIN PASSWORD 'abis_controller';
CREATE DATABASE abis_controller WITH OWNER abis_controller;
\q
