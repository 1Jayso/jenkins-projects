﻿

DROP SEQUENCE if exists abislongid;
CREATE SEQUENCE abislongid
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 9223372036854775807
  START 5
  CACHE 1;
  
----------SCRIPTS FOR GK_DOMAIN TABLE -----
  
DROP TABLE if exists gk_domain cascade;

CREATE TABLE gk_domain
(
  pk_id character varying(255) NOT NULL,
  time_stamp bigint,
  domain_name character varying(255) NOT NULL,
  test_domain integer default 0,
  registration_schema character varying(255),
  biographic_schema character varying(255),
  CONSTRAINT gk_domain_pkey PRIMARY KEY (pk_id ),
  CONSTRAINT gk_domain_domain_name_key UNIQUE (domain_name )
)
WITH (
  OIDS=FALSE
);

  
  ----------SCRIPTS FOR gk_domain_profile TABLE -----
  
DROP TABLE if exists gk_domain_profile cascade;

CREATE TABLE gk_domain_profile
(
  pk_id character varying(255) NOT NULL,
  time_stamp bigint,
  fk_domain_id character varying(255),
  biographic_id character varying(255) NOT NULL,
  biographic_xml text,
  registration_xml text,
  photo bytea,
  CONSTRAINT gk_domain_profile_pkey PRIMARY KEY (pk_id ),
  CONSTRAINT fkcd1f7de9298a462e FOREIGN KEY (fk_domain_id)
      REFERENCES gk_domain (pk_id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION,
  CONSTRAINT gk_domain_profile_fk_domain_id_biographic_id_key UNIQUE (fk_domain_id , biographic_id )
)
WITH (
  OIDS=FALSE
);

CREATE INDEX biographicid_index
  ON gk_domain_profile
  USING btree
  (biographic_id COLLATE pg_catalog."default" );

CREATE INDEX domain_profile_ts_index
  ON gk_domain_profile
  USING btree
  (time_stamp );


----------SCRIPTS FOR gk_biometric_duplicate TABLE -----
  
DROP TABLE if exists gk_biometric_duplicate cascade;
  
CREATE TABLE gk_biometric_duplicate
(
  pk_id character varying(255) NOT NULL,
  time_stamp bigint,
  profile_id character varying(255) NOT NULL,
  duplicate_id character varying(255) NOT NULL,
  decision character varying(255),
  match_score double precision NOT NULL,
  normalised_far double precision,
  log_far double precision,
  log_frr double precision,
  fingercount integer,
  result_category character varying(255),
  match_elements_xml text,
  duplicate_source character varying(255),
  duplicate_decision character varying(255),
  biographic_score double precision,
  face_score double precision,
  iris_score double precision,
  duplicate_set character varying(255),
  CONSTRAINT gk_biometric_duplicate_pkey PRIMARY KEY (pk_id ),
  CONSTRAINT gk_biometric_duplicate_profile_id_duplicate_id_key UNIQUE (profile_id , duplicate_id )
)
WITH (
  OIDS=FALSE
);


CREATE INDEX biometric_duplicate_ts_index
  ON gk_biometric_duplicate
  USING btree
  (time_stamp );


----------SCRIPTS FOR gk_biometric_request TABLE -----
  
DROP TABLE if exists gk_biometric_request cascade;
  
CREATE TABLE gk_biometric_request
(
  pk_id character varying(255) NOT NULL,
  time_stamp bigint,
  external_request_id character varying(255),
  node_type character varying(255),
  transport_medium character varying(255),
  operation_state character varying(255),
  receipt_time timestamp without time zone NOT NULL,
  operation character varying(255),
  subject_id bigint,
  domain_profile_id character varying(255),
  message_source character varying (255), 
  batch_id character varying(64),	
  CONSTRAINT gk_biometric_request_pkey PRIMARY KEY (pk_id ),
  CONSTRAINT fkdc60f36ddc479c63 FOREIGN KEY (domain_profile_id)
      REFERENCES gk_domain_profile (pk_id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION
)
WITH (
  OIDS=FALSE
);


-- DROP INDEX req_dom_prof_id_idx;

CREATE INDEX req_dom_prof_id_idx
  ON gk_biometric_request
  USING btree
  (domain_profile_id COLLATE pg_catalog."default" );

-- Index: req_subject_id_idx

-- DROP INDEX req_subject_id_idx;

CREATE INDEX req_subject_id_idx
  ON gk_biometric_request
  USING btree
  (subject_id );

CREATE INDEX biometric_request_ts_index
  ON gk_biometric_request
  USING btree
  (time_stamp );


----------SCRIPTS FOR gk_biometric_response TABLE -----
  
DROP TABLE if exists gk_biometric_response cascade;

CREATE TABLE gk_biometric_response
(
  pk_id character varying(255) NOT NULL,
  response_type character varying(255) NOT NULL,
  dispatch_time timestamp without time zone,
  process_time bigint,
  node_type character varying(255),
  operation_result character varying(255),
  request_id character varying(255),
  CONSTRAINT gk_biometric_response_pkey PRIMARY KEY (pk_id ),
  CONSTRAINT fkb2e52f232cab04e1 FOREIGN KEY (request_id)
      REFERENCES gk_biometric_request (pk_id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION
)
WITH (
  OIDS=FALSE
);


CREATE INDEX resp_req_id_idx
  ON gk_biometric_response
  USING btree
  (request_id COLLATE pg_catalog."default" );

CREATE INDEX biometric_response_ts_index
  ON gk_biometric_response
  USING btree
  (dispatch_time);


----------SCRIPTS FOR gk_adjudication_result TABLE -----
  
DROP TABLE if exists gk_adjudication_result cascade;

CREATE TABLE gk_adjudication_result
(
  pk_id character varying(255) NOT NULL,
  time_stamp bigint,
  subject_id character varying(255) NOT NULL,
  duplicate_subject_id character varying(255),
  adjudication_comment character varying(255),
  is_duplicate boolean,
  CONSTRAINT gk_adjudication_result_pkey PRIMARY KEY (pk_id )
)
WITH (
  OIDS=FALSE
);

CREATE TABLE gk_clustered_job
(
	pk_id character varying(64) not NULL,
	job_status character varying(32) not NULL default 'Available',
	task_type character varying(32) not null,
	task_name character varying(64) not null,
	processor_state	character varying(255),
	processor_id character varying(64), 
	last_update_time timestamp,
	CONSTRAINT clustered_job_pkey PRIMARY KEY (pk_id)
 );

 create index cluster_task_index on gk_clustered_job using btree (task_type, task_name);

 CREATE TABLE gk_clustered_lock
(
  pk_id bigint NOT NULL,
  lock_name character varying(255),
  lock_status character varying(255) NOT NULL DEFAULT 'FREE'::character varying,
  lock_owner character varying(255) NOT NULL,
  time_stamp bigint NOT NULL,
  max_duration bigint,
  owner character varying(255) NOT NULL,
  CONSTRAINT gk_clustered_lock_pkey PRIMARY KEY (pk_id)
);

CREATE INDEX lock_name_index
  ON gk_clustered_lock
  USING btree (lock_name);


 

