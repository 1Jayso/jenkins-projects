--
-- PostgreSQL database dump
--

-- Dumped from database version 9.3.9
-- Dumped by pg_dump version 9.3.9
-- Started on 2021-02-13 10:14:51

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

--
-- TOC entry 2078 (class 0 OID 91610902)
-- Dependencies: 173
-- Data for Name: act_ge_property; Type: TABLE DATA; Schema: public; Owner: gkadjudication
--

INSERT INTO act_ge_property VALUES ('schema.version', '5.21.0.0', 1);
INSERT INTO act_ge_property VALUES ('schema.history', 'create(5.21.0.0)', 1);
INSERT INTO act_ge_property VALUES ('next.dbid', '1', 1);


-- Completed on 2021-02-13 10:14:51

--
-- PostgreSQL database dump complete
--

