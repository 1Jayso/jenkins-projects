ALTER TABLE public.adj_case_lookup
    ALTER COLUMN case_details TYPE text COLLATE pg_catalog."default";
