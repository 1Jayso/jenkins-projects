--
-- PostgreSQL database dump
--

-- Dumped from database version 9.3.25
-- Dumped by pg_dump version 12.0

-- Started on 2020-05-06 02:58:16

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 11 (class 2615 OID 923603)
-- Name: commongateway; Type: SCHEMA; Schema: -; Owner: gkspire
--

CREATE SCHEMA commongateway;


ALTER SCHEMA commongateway OWNER TO gkspire;

--
-- TOC entry 318 (class 1259 OID 923625)
-- Name: abis_biometric_profile; Type: VIEW; Schema: commongateway; Owner: gkspire
--

CREATE VIEW commongateway.abis_biometric_profile AS
 SELECT prim_biometric_profile.record_id,
    prim_biometric_profile.created,
    prim_biometric_profile.created_by,
    prim_biometric_profile.gk_id,
    prim_biometric_profile.record_status,
    prim_biometric_profile.version_,
    prim_biometric_profile.archived,
    prim_biometric_profile.biometric_profile,
    prim_biometric_profile.operation,
    prim_biometric_profile.processed,
    prim_biometric_profile.replaces,
    prim_biometric_profile.process_error_code,
    prim_biometric_profile.bio_hash_data
   FROM public.prim_biometric_profile;


ALTER TABLE commongateway.abis_biometric_profile OWNER TO gkspire;

SET default_tablespace = '';

--
-- TOC entry 315 (class 1259 OID 923604)
-- Name: abis_gateway_duplicate; Type: TABLE; Schema: commongateway; Owner: gkspire
--

CREATE TABLE commongateway.abis_gateway_duplicate (
    pk_id character varying(255) NOT NULL,
    biographic_id1 character varying(255),
    biographic_id2 character varying(255),
    abis25_score double precision,
    abis3_score double precision,
    is_duplicate integer,
    abis25_updated timestamp without time zone,
    abis3_updated timestamp without time zone
);


ALTER TABLE commongateway.abis_gateway_duplicate OWNER TO gkspire;

--
-- TOC entry 316 (class 1259 OID 923616)
-- Name: abis_gateway_result; Type: TABLE; Schema: commongateway; Owner: gkspire
--

CREATE TABLE commongateway.abis_gateway_result (
    batch_id character varying(64) NOT NULL,
    legacy_result character varying(32),
    inspect_result character varying(32)
);


ALTER TABLE commongateway.abis_gateway_result OWNER TO gkspire;

--
-- TOC entry 3366 (class 2606 OID 923613)
-- Name: abis_gateway_duplicate abis_gateway_duplicate_pkey; Type: CONSTRAINT; Schema: commongateway; Owner: gkspire
--

ALTER TABLE ONLY commongateway.abis_gateway_duplicate
    ADD CONSTRAINT abis_gateway_duplicate_pkey PRIMARY KEY (pk_id);


--
-- TOC entry 3368 (class 2606 OID 923620)
-- Name: abis_gateway_result abis_gateway_result_pkey; Type: CONSTRAINT; Schema: commongateway; Owner: gkspire
--

ALTER TABLE ONLY commongateway.abis_gateway_result
    ADD CONSTRAINT abis_gateway_result_pkey PRIMARY KEY (batch_id);
	
	
-- View: public.abis_biometric_profile

-- DROP VIEW public.abis_biometric_profile;

CREATE OR REPLACE VIEW public.abis_biometric_profile AS
 SELECT prim_biometric_profile.record_id,
    prim_biometric_profile.created,
    prim_biometric_profile.created_by,
    prim_biometric_profile.gk_id,
    prim_biometric_profile.record_status,
    prim_biometric_profile.version_,
    prim_biometric_profile.archived,
    prim_biometric_profile.biometric_profile,
    prim_biometric_profile.operation,
    prim_biometric_profile.processed,
    prim_biometric_profile.replaces,
    prim_biometric_profile.process_error_code,
    prim_biometric_profile.bio_hash_data
   FROM public.prim_biometric_profile;

ALTER TABLE public.abis_biometric_profile
    OWNER TO gkspire;


-- Completed on 2020-05-06 02:58:16

--
-- PostgreSQL database dump complete
--

