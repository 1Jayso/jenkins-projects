Naming convention:
V0.0.X__<description>.sql

Where 
- V stands for db script to be executed 
- 0 for the base extension
- 0 for spire database
- X numeric, ascending sequence of files


ONCE A FILE IS COMMITTED TO SVN THE CONTENT SHALL NEVER BE CHANGED !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!




