CREATE ROLE gkspire WITH SUPERUSER LOGIN PASSWORD 'gkspire';
CREATE DATABASE gkspire WITH OWNER gkspire;

CREATE ROLE gkadjudication WITH SUPERUSER LOGIN PASSWORD 'gkadjudication';
CREATE DATABASE gkadjudication WITH OWNER gkadjudication;
\q
