/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  abin.m
 * Created: 26 Apr, 2022
 */


ALTER TABLE user_cases_view RENAME COLUMN "user" TO username;


ALTER TABLE user_decisions_view RENAME COLUMN "user" TO username;
