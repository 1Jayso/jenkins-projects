
Drop table if exists Members;
Drop table if exists MemberGroups;
Drop table if exists memberfps;
Drop table if exists memberface;
drop table if exists test_entity;
CREATE TABLE public.memberface (
    gkid character varying(64) NOT NULL,
    created bigint,
    updated bigint,
    image_format character varying(16),
    image_data bytea
);


ALTER TABLE public.memberface OWNER TO postgres;


CREATE TABLE public.memberfps (
    gkid character varying(64) NOT NULL,
    created bigint,
    updated bigint,
    fpformat character varying(16),
    nist_1 bytea,
    nist_2 bytea,
    nist_3 bytea,
    nist_4 bytea,
    nist_5 bytea,
    nist_6 bytea,
    nist_7 bytea,
    nist_8 bytea,
    nist_9 bytea,
    nist_10 bytea
);


ALTER TABLE public.memberfps OWNER TO postgres;

CREATE TABLE public.membergroups (
    groupid character varying(64) NOT NULL
);


ALTER TABLE public.membergroups OWNER TO postgres;


CREATE TABLE public.members (
    gkid character varying(64) NOT NULL,
    public_person_id character varying(64),
    firstnames character varying(64),
    surname character varying(64),
    gender character varying(16),
    other_names_1 character varying(64),
    date_of_birth bigint,
    date_of_birth_known integer,
    original_id character varying(64),
    regdate bigint,
    lasttransdate bigint,
    age_reg integer,
    assigned_group character varying(64),
    member_type character varying(64),
    adjstatus character varying(64),
    adjprocessstatus character varying(64),
    adjdateentered bigint,
    adjdateduplicated bigint,
    adjlastdateduplicated bigint,
    adjerrorcode character varying(64),
    adrbusiness character varying(64),
    adrresidential character varying(64),
    adrresidentialother character varying(64),
    adrpostal character varying(64),
    adrpostalother character varying(64),
    adrbusinesscc character varying(64),
    adrresidentialcc character varying(64),
    adrresidentialothercc character varying(64),
    adrpostalcc character varying(64),
    adrpostalothercc character varying(64),
    adrbusinessdetail character varying(64),
    adrresidentialdetail character varying(64),
    adrresidentialotherdetail character varying(64),
    adrpostaldetail character varying(64),
    adrpostalotherdetail character varying(64),
    adrbusinesspc character varying(64),
    adrresidentialpc character varying(64),
    adrresidentialotherpc character varying(64),
    adrpostalpc character varying(64),
    adrpostalotherpc character varying(64),
    ctcemail character varying(64),
    ctcphone1 character varying(64),
    ctcphone2 character varying(64),
    ctcphone3 character varying(64),
    ctcmobile1 character varying(64),
    ctcmobile2 character varying(64),
    ctcmobile3 character varying(64),
    ctcmailbox character varying(64),
    ctcother character varying(64),
    personstatus character varying(32),
    personstatussince bigint,
    idnational character varying(64),
    idinsurance character varying(64),
    idalien character varying(64),
    idrefugee character varying(64),
    idpassport character varying(64),
    idcivilservice character varying(64),
    idbirthcert character varying(64),
    idbirthnotcard character varying(64),
    iddriverlicense character varying(64),
    idstudentid character varying(64),
    idsocsecurity character varying(64),
    idvoter character varying(64),
    idother character varying(64),
    lasttranscenter character varying(64),
    lasttransstation character varying(64),
    lasttransofficerid character varying(64),
    lasttransofficername character varying(64),
    regcenter character varying(64),
    regstation character varying(64),
    regofficerid character varying(64),
    regofficername character varying(64),
    countryofbirth character varying(32),
    incomplete integer
);


ALTER TABLE public.members OWNER TO postgres;


CREATE TABLE public.test_entity (
    id integer NOT NULL
);


ALTER TABLE public.test_entity OWNER TO gkspire;


ALTER TABLE ONLY public.memberface
    ADD CONSTRAINT memberface_pkey PRIMARY KEY (gkid);



ALTER TABLE ONLY public.memberfps
    ADD CONSTRAINT memberfps_pkey PRIMARY KEY (gkid);


ALTER TABLE ONLY public.membergroups
    ADD CONSTRAINT membergroups_pkey PRIMARY KEY (groupid);



ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_pkey PRIMARY KEY (gkid);


ALTER TABLE ONLY public.test_entity
    ADD CONSTRAINT test_entity_pkey PRIMARY KEY (id);



